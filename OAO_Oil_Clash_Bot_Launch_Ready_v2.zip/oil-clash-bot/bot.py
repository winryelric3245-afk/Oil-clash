"""Oil Clash: standalone Discord slash-command bot for Tiles Survive."""
from __future__ import annotations

import io
import logging
import os

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from storage import OilDB, parse_player_lines

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
TEST_GUILD_ID = os.getenv("TEST_GUILD_ID", "").strip()
DB_PATH = os.getenv("OIL_DB_PATH", "data/oil_clash.sqlite3")
ADMIN_ROLE_IDS = {
    int(s.strip()) for s in os.getenv("OIL_ADMIN_ROLE_IDS", "").split(",")
    if s.strip().isdigit()
}
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("oilclash")
db = OilDB(DB_PATH)

intents = discord.Intents.default()
intents.message_content = False
intents.members = False
bot = commands.Bot(command_prefix="!unused-", intents=intents)
oil = app_commands.Group(name="oil", description="Oil Clash anchors and alliance roles")


def gid(interaction: discord.Interaction) -> int:
    if interaction.guild_id is None:
        raise ValueError("Use Oil Clash commands inside your alliance Discord server.")
    return interaction.guild_id


def ensure_admin(interaction: discord.Interaction) -> None:
    if not isinstance(interaction.user, discord.Member):
        raise ValueError("Admin commands must be used in a server.")
    if interaction.user.guild_permissions.manage_guild:
        return
    if any(r.id in ADMIN_ROLE_IDS for r in interaction.user.roles):
        return
    raise ValueError("Admin only. Requires Manage Server or a configured Oil Clash admin role.")


async def respond_error(interaction: discord.Interaction, message: str) -> None:
    message = "❌ " + message[:1700]
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


async def player_suggestions(interaction: discord.Interaction, current: str):
    try:
        matches = [p["name"] for p in db.roster(gid(interaction)) if current.casefold() in p["name"].casefold()]
        return [app_commands.Choice(name=n[:100], value=n[:100]) for n in matches[:25]]
    except ValueError:
        return []


async def role_suggestions(interaction: discord.Interaction, current: str):
    try:
        matches = [r for r in db.role_types(gid(interaction)) if current.casefold() in r.casefold()]
        return [app_commands.Choice(name=r, value=r) for r in matches[:25]]
    except ValueError:
        return []


# Persistent, mobile-friendly panel. Buttons survive restarts (registered in setup_hook).
def panel_embed(server_id: int) -> discord.Embed:
    setting = db.settings(server_id)
    members = db.roster(server_id)
    ready = sum(bool(p["online_before_reset"]) for p in members)
    anchors_reported = [p for p in members if p["anchors"] is not None]
    total = sum(p["anchors"] for p in anchors_reported)
    card = discord.Embed(
        title=f"🛢️ OIL CLASH | Day {setting['day']} / 7",
        description=(
            "**Tap to check in for today.**\n"
            "🟢 ✅ = online before reset\n"
            "🔴 ❌ = not confirmed online before reset\n"
            "⚓ = enter or change anchors (1–25)\n"
            "👤 = link your game name (once)"
        ),
        color=discord.Color.green() if members and ready == len(members) else discord.Color.orange(),
    )
    card.add_field(name="🟢 Online", value=f"**{ready}/{len(members)}**", inline=True)
    card.add_field(name="🔴 Not confirmed", value=f"**{len(members)-ready}**", inline=True)
    card.add_field(name="⚓ Reported anchors", value=f"**{total}** · {len(anchors_reported)}/{len(members)} players", inline=False)
    card.set_footer(text=f"Event #{setting['event_number']} · Daily status resets when an admin changes the day")
    return card


async def refresh_panel(interaction: discord.Interaction, source: discord.Message | None = None) -> None:
    """Best-effort refresh; member check-in is saved even if message edit fails."""
    message = source or interaction.message
    if message is None or interaction.guild_id is None:
        return
    try:
        await message.edit(embed=panel_embed(interaction.guild_id), view=OilPanel())
    except (discord.HTTPException, discord.Forbidden) as exc:
        log.warning("Could not refresh Oil Clash panel: %s", exc)


async def update_saved_panel(server_id: int) -> None:
    """Keep the posted summary updated even when members use slash commands."""
    location = db.panel_location(server_id)
    if not location:
        return
    channel_id, message_id = location
    try:
        channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
        message = await channel.fetch_message(message_id)
        await message.edit(embed=panel_embed(server_id), view=OilPanel())
    except (discord.HTTPException, discord.Forbidden, AttributeError) as exc:
        log.warning("Could not update saved Oil Clash panel %s/%s: %s", channel_id, message_id, exc)


def linked_player(interaction: discord.Interaction) -> dict:
    p = db.report_for_member(gid(interaction), interaction.user.id)
    if not p:
        raise ValueError("First tap 👤 Set Game Name to link your in-game name, then check in.")
    return p


class AnchorModal(discord.ui.Modal, title="Oil Clash • Anchors"):
    amount = discord.ui.TextInput(label="How many anchors do you have? (1–25)", placeholder="Example: 23", min_length=1, max_length=2)

    def __init__(self, source: discord.Message | None):
        super().__init__(timeout=300)
        self.source = source

    async def on_submit(self, interaction: discord.Interaction):
        try:
            p = linked_player(interaction)
            value_text = str(self.amount.value).strip()
            if not value_text.isdecimal():
                raise ValueError("Enter a whole number from 1 to 25.")
            value = int(value_text)
            setting = db.report_anchors(gid(interaction), p["id"], value)
            await interaction.response.send_message(f"✅ {value} anchors saved for Day {setting['day']}.", ephemeral=True)
            await refresh_panel(interaction, self.source)
        except (ValueError, TypeError) as exc:
            await respond_error(interaction, str(exc) if str(exc) else "Enter a whole number from 1 to 25.")


class NameModal(discord.ui.Modal, title="Oil Clash • Your Game Name"):
    game_name = discord.ui.TextInput(label="Your exact in-game name", placeholder="Must match the imported roster name, if present", max_length=64)

    def __init__(self, source: discord.Message | None):
        super().__init__(timeout=300)
        self.source = source

    async def on_submit(self, interaction: discord.Interaction):
        try:
            db.register(gid(interaction), interaction.user.id, str(self.game_name.value))
            await interaction.response.send_message(f"✅ Linked as **{discord.utils.escape_markdown(str(self.game_name.value))}**. You can now check in.", ephemeral=True)
            await refresh_panel(interaction, self.source)
        except ValueError as exc:
            await respond_error(interaction, str(exc))


class OilPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Online before reset", emoji="✅", style=discord.ButtonStyle.success, custom_id="oil_clash:v2:ready")
    async def ready(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            p = linked_player(interaction)
            setting = db.report_online(gid(interaction), p["id"], True)
            await interaction.response.send_message(f"🟢 ✅ You're marked **online before reset** for Day {setting['day']}.", ephemeral=True)
            await refresh_panel(interaction)
        except ValueError as exc:
            await respond_error(interaction, str(exc))

    @discord.ui.button(label="Not online", emoji="❌", style=discord.ButtonStyle.danger, custom_id="oil_clash:v2:not_ready")
    async def not_ready(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            p = linked_player(interaction)
            setting = db.report_online(gid(interaction), p["id"], False)
            await interaction.response.send_message(f"🔴 ❌ You're marked **not online before reset** for Day {setting['day']}.", ephemeral=True)
            await refresh_panel(interaction)
        except ValueError as exc:
            await respond_error(interaction, str(exc))

    @discord.ui.button(label="Anchors", emoji="⚓", style=discord.ButtonStyle.primary, custom_id="oil_clash:v2:anchors")
    async def anchors_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            linked_player(interaction)
            await interaction.response.send_modal(AnchorModal(interaction.message))
        except ValueError as exc:
            await respond_error(interaction, str(exc))

    @discord.ui.button(label="Set Game Name", emoji="👤", style=discord.ButtonStyle.secondary, custom_id="oil_clash:v2:name")
    async def name_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if db.report_for_member(gid(interaction), interaction.user.id):
            await interaction.response.send_message("✅ You're already linked. Ask an admin to rename your saved profile if needed.", ephemeral=True)
        else:
            await interaction.response.send_modal(NameModal(interaction.message))


@oil.command(name="panel", description="ADMIN: Post the simple Oil Clash check-in buttons")
async def panel(interaction: discord.Interaction):
    ensure_admin(interaction)
    await interaction.response.send_message(embed=panel_embed(gid(interaction)), view=OilPanel(), allowed_mentions=discord.AllowedMentions.none())
    message = await interaction.original_response()
    db.save_panel(gid(interaction), interaction.channel_id, message.id)


@oil.command(name="checkin", description="Save your anchors and before-reset availability together")
@app_commands.describe(anchors="Your anchors right now (1–25)", online_before_reset="Will you be online before reset?")
async def checkin(interaction: discord.Interaction, anchors: app_commands.Range[int, 1, 25], online_before_reset: bool):
    p = linked_player(interaction)
    setting = db.report_anchors(gid(interaction), p["id"], anchors)
    db.report_online(gid(interaction), p["id"], online_before_reset)
    status = "🟢 ✅ online" if online_before_reset else "🔴 ❌ not online"
    await interaction.response.send_message(f"✅ Day {setting['day']}: **{anchors}** anchors · {status} before reset.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="set_online", description="ADMIN: Set a player's before-reset availability")
@app_commands.autocomplete(player=player_suggestions)
async def set_online(interaction: discord.Interaction, player: str, online: bool):
    ensure_admin(interaction)
    setting = db.admin_online(gid(interaction), player, online)
    status = "🟢 ✅ online" if online else "🔴 ❌ not online"
    await interaction.response.send_message(f"**{discord.utils.escape_markdown(player)}**: {status} before reset (Day {setting['day']}).", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="help", description="Show player and admin commands")
async def oil_help(interaction: discord.Interaction):
    info = (
        "**Oil Clash — simple check-ins**\n"
        "`/oil panel` (admin) — post the button panel.\n"
        "Members: tap 👤 **Set Game Name** once, then ⚓ **Anchors** and 🟢/🔴 **before reset**.\n"
        "Or use `/oil checkin` to enter both together.\n"
        "`/oil me` — your status; `/oil roster` — everyone; `/oil summary` — totals.\n\n"
        "**Admin shortcuts**\n"
        "`/oil batch` — add the roster in one paste or .txt file.\n"
        "`/oil role_add` / `role_remove` — assign roles.\n"
        "`/oil set_online` / `set_anchors` — fix reports.\n"
        "`/oil day` — change Day 1–7; `/oil new_event` — start new round.\n"
        "`/oil export` — get the CSV.\n"
        "**Green = confirmed online. Red = not confirmed.** "
        "Statuses and anchors are day-specific; saved players and roles remain."
    )
    await interaction.response.send_message(info, ephemeral=True)


@oil.command(name="register", description="Link your game name to your Discord account")
@app_commands.describe(game_name="Your exact in-game name", march_power_m="Optional: highest march power in millions (e.g. 35.5)")
async def register(interaction: discord.Interaction, game_name: str, march_power_m: float | None = None):
    player_id = db.register(gid(interaction), interaction.user.id, game_name, march_power_m)
    await interaction.response.send_message(f"✅ Registered **{discord.utils.escape_markdown(game_name)}**. Your roles and reports are saved. (Player #{player_id})", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="power", description="Update your highest march power (millions)")
@app_commands.describe(march_power_m="Example: 45.2 for 45.2M")
async def power(interaction: discord.Interaction, march_power_m: float):
    current = db.report_for_member(gid(interaction), interaction.user.id)
    if current is None:
        raise ValueError("First tap 👤 Set Game Name or use /oil register.")
    db.upsert_player(gid(interaction), current["name"], discord_id=interaction.user.id, power_m=march_power_m)
    await interaction.response.send_message(f"✅ Highest march power: **{march_power_m:g}M**.", ephemeral=True)


@oil.command(name="anchors", description="Check in with your current anchors (1–25)")
@app_commands.describe(count="Your current usable/saved anchors, 1–25")
async def anchors(interaction: discord.Interaction, count: app_commands.Range[int, 1, 25]):
    player = linked_player(interaction)
    setting = db.report_anchors(gid(interaction), player["id"], count)
    await interaction.response.send_message(
        f"✅ **{count} anchors** recorded for **Oil Clash Day {setting['day']}**. "
        "Run `/oil anchors` again whenever your count changes.", ephemeral=True
    )
    await update_saved_panel(gid(interaction))


@oil.command(name="me", description="Check your Oil Clash player profile")
async def me(interaction: discord.Interaction):
    p = db.report_for_member(gid(interaction), interaction.user.id)
    if not p:
        await interaction.response.send_message("You're not registered yet. Tap 👤 on the Oil Clash panel, or use `/oil register`.", ephemeral=True)
        return
    s = db.settings(gid(interaction))
    power_text = f"{p['power_m']:g}M" if p["power_m"] is not None else "not entered"
    status_text = "🟢 ✅ Online before reset" if p["online_before_reset"] else "🔴 ❌ Not confirmed online before reset"
    anchors_text = str(p["anchors"]) if p["anchors"] is not None else "not reported"
    await interaction.response.send_message(
        f"**{p['name']}** — Event {s['event_number']}, Day {s['day']}\n"
        f"Anchors: **{anchors_text}**\nReset: **{status_text}**\nRoles: **{p['roles'] or 'Unassigned'}**\nHighest march: **{power_text}**", ephemeral=True
    )


@oil.command(name="roster", description="Show roster, daily anchors, roles, and missing check-ins")
@app_commands.describe(role="Optional role filter", missing_only="Only missing anchor reports", not_online_only="Only red (not confirmed)", public="Post in channel instead of privately")
@app_commands.autocomplete(role=role_suggestions)
async def roster(interaction: discord.Interaction, role: str | None = None, missing_only: bool = False, not_online_only: bool = False, public: bool = False):
    s = db.settings(gid(interaction))
    people = db.roster(gid(interaction))
    if role:
        people = [p for p in people if role.casefold() in [x.casefold() for x in p["roles"].split(", ")]]
    if missing_only:
        people = [p for p in people if p["anchors"] is None]
    if not_online_only:
        people = [p for p in people if not p["online_before_reset"]]
    title = f"OIL CLASH | Event {s['event_number']} · Day {s['day']}"
    if not people:
        await interaction.response.send_message(f"**{title}**\nNo players match the current filters.", ephemeral=not public)
        return
    lines = []
    for p in people:
        number = str(p["anchors"]) if p["anchors"] is not None else "—"
        pw = f" · {p['power_m']:g}M" if p["power_m"] is not None else ""
        status = "🟢 ✅" if p["online_before_reset"] else "🔴 ❌"
        line = f"{status} **{discord.utils.escape_markdown(p['name'])}** · {number} ⚓ · {discord.utils.escape_markdown(p['roles'] or 'Unassigned')}{pw}"
        lines.append(line)
    reported = sum(p["anchors"] is not None for p in people)
    online = sum(p["online_before_reset"] for p in people)
    heading = f"**{title}**\n🟢 {online} online · 🔴 {len(people)-online} not confirmed · ⚓ {reported}/{len(people)} reported\n\n"
    body = "\n".join(lines)
    if len(heading + body) <= 1900:
        await interaction.response.send_message(heading + body, ephemeral=not public, allowed_mentions=discord.AllowedMentions.none())
    else:
        safe_lines = [f"{'GREEN online' if p['online_before_reset'] else 'RED not confirmed'} | {p['name']} | {p['anchors'] if p['anchors'] is not None else '-'} anchors | {p['roles'] or 'Unassigned'} | {p['power_m'] if p['power_m'] is not None else '-'}M" for p in people]
        out = (title + "\nReset | Player | Anchors | Roles | Power\n\n" + "\n".join(safe_lines)).encode("utf-8")
        preview_lines = []
        current_length = len(heading) + 45
        for line in lines:
            if current_length + len(line) > 1750 or len(preview_lines) == 15:
                break
            preview_lines.append(line)
            current_length += len(line) + 1
        preview = "\n".join(preview_lines)
        await interaction.response.send_message(
            heading + preview + "\n…Full list attached.",
            file=discord.File(io.BytesIO(out), filename="oil_clash_roster.txt"),
            ephemeral=not public, allowed_mentions=discord.AllowedMentions.none()
        )


@oil.command(name="summary", description="Team anchor totals and missing check-ins")
@app_commands.describe(public="Post in channel instead of privately")
async def summary(interaction: discord.Interaction, public: bool = False):
    s = db.settings(gid(interaction))
    people = db.roster(gid(interaction))
    completed = [p for p in people if p["anchors"] is not None]
    not_ready = [p["name"] for p in people if not p["online_before_reset"]]
    missing = [p["name"] for p in people if p["anchors"] is None]
    total = sum(p["anchors"] for p in completed)
    ready = sum(bool(p["online_before_reset"]) for p in people)
    roles = db.role_types(gid(interaction))
    details = []
    for role in roles:
        assigned = [p for p in people if role.casefold() in [x.casefold() for x in p["roles"].split(", ")]]
        if assigned:
            reported = sum(p["anchors"] is not None for p in assigned)
            count = sum(p["anchors"] or 0 for p in assigned)
            online = sum(bool(p["online_before_reset"]) for p in assigned)
            details.append(f"{role}: **{count}** anchors · 🟢 {online}/{len(assigned)} online · ⚓ {reported}/{len(assigned)} reported")
    msg = (
        f"**OIL CLASH SUMMARY — Event {s['event_number']}, Day {s['day']}**\n"
        f"Members: **{len(people)}** · Reported: **{len(completed)}** · Missing: **{len(missing)}**\n"
        f"🟢 Online before reset: **{ready}** · 🔴 Not confirmed: **{len(people)-ready}**\n"
        f"Total reported anchors: **{total}**\n\n"
        + ("\n".join(details) if details else "No assigned roles yet.")
        + "\n\n*Role totals may overlap for members with multiple roles.*"
        + ("\n🔴 Not confirmed: " + ", ".join(discord.utils.escape_markdown(n) for n in not_ready[:15]) + (f" (+{len(not_ready)-15} more)" if len(not_ready) > 15 else "") if not_ready else "")
        + ("\n⚓ Missing anchors: " + ", ".join(discord.utils.escape_markdown(n) for n in missing[:15]) + (f" (+{len(missing)-15} more)" if len(missing) > 15 else "") if missing else "")
    )
    await interaction.response.send_message(msg[:1900], ephemeral=not public, allowed_mentions=discord.AllowedMentions.none())


@oil.command(name="batch", description="ADMIN: Add/update many game names, roles, power and optional Discord IDs")
@app_commands.describe(players="Paste one player per line (or attach a .txt file)", file="Optional UTF-8 .txt roster for large imports")
async def batch(interaction: discord.Interaction, players: str | None = None, file: discord.Attachment | None = None):
    ensure_admin(interaction)
    if not players and not file:
        raise ValueError("Paste players or attach a .txt file. Format: Name | Lair Hitter | 35.5M | @DiscordUser")
    await interaction.response.defer(ephemeral=True)
    payload = players or ""
    if file:
        if file.size > 80_000:
            raise ValueError("Import file must be under 80 KB.")
        try:
            payload += "\n" + (await file.read()).decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("Roster file must be UTF-8 text.") from exc
    records, parse_errors = parse_player_lines(payload)
    if len(records) > 500:
        raise ValueError("Maximum 500 players per batch.")
    ok, import_errors = db.batch(gid(interaction), records)
    errors = parse_errors + import_errors
    result = f"✅ **{ok} players added/updated**. Names, roles, and Discord links are saved."
    if errors:
        result += f"\n⚠️ {len(errors)} skipped/errors:\n" + "\n".join(errors[:12])
        if len(errors) > 12:
            result += f"\n...and {len(errors) - 12} more."
    await interaction.followup.send(result[:1900], ephemeral=True)
    if ok:
        await update_saved_panel(gid(interaction))


@oil.command(name="role_new", description="ADMIN: Create a role (e.g., Flex or Rig Backup)")
async def role_new(interaction: discord.Interaction, name: str):
    ensure_admin(interaction)
    db.add_role_type(gid(interaction), name)
    await interaction.response.send_message(f"✅ Role **{name}** is available for assignment.", ephemeral=True)


@oil.command(name="role_list", description="Show Oil Clash role labels")
async def role_list(interaction: discord.Interaction):
    roles = db.role_types(gid(interaction))
    await interaction.response.send_message("**Oil Clash roles:** " + (", ".join(roles) or "none"), ephemeral=True)


@oil.command(name="role_add", description="ADMIN: Assign another role to a player")
@app_commands.autocomplete(player=player_suggestions, role=role_suggestions)
async def role_add(interaction: discord.Interaction, player: str, role: str):
    ensure_admin(interaction)
    db.add_player_role(gid(interaction), player, role)
    await interaction.response.send_message(f"✅ **{player}** now has **{role}**.", ephemeral=True)


@oil.command(name="role_remove", description="ADMIN: Remove a role from a player")
@app_commands.autocomplete(player=player_suggestions, role=role_suggestions)
async def role_remove(interaction: discord.Interaction, player: str, role: str):
    ensure_admin(interaction)
    db.remove_player_role(gid(interaction), player, role)
    await interaction.response.send_message(f"✅ Removed **{role}** from **{player}**.", ephemeral=True)


@oil.command(name="link", description="ADMIN: Connect imported game name to a Discord member")
@app_commands.autocomplete(player=player_suggestions)
async def link(interaction: discord.Interaction, player: str, member: discord.Member):
    ensure_admin(interaction)
    db.admin_link(gid(interaction), player, member.id)
    await interaction.response.send_message(f"✅ Linked **{player}** to **{member.display_name}**.", ephemeral=True)


@oil.command(name="unlink", description="ADMIN: Disconnect a game name from its Discord member")
@app_commands.autocomplete(player=player_suggestions)
async def unlink(interaction: discord.Interaction, player: str):
    ensure_admin(interaction)
    db.unlink(gid(interaction), player)
    await interaction.response.send_message(f"✅ Unlinked **{player}**. Roles and reports remain.", ephemeral=True)


@oil.command(name="rename", description="ADMIN: Change a saved in-game name without losing reports")
@app_commands.autocomplete(player=player_suggestions)
async def rename(interaction: discord.Interaction, player: str, new_name: str):
    ensure_admin(interaction)
    db.rename(gid(interaction), player, new_name)
    await interaction.response.send_message(f"✅ Renamed **{player}** → **{new_name}**.", ephemeral=True)


@oil.command(name="set_anchors", description="ADMIN: Correct a player's anchors for the active day")
@app_commands.autocomplete(player=player_suggestions)
async def set_anchors(interaction: discord.Interaction, player: str, count: app_commands.Range[int, 1, 25]):
    ensure_admin(interaction)
    setting = db.admin_report(gid(interaction), player, count)
    await interaction.response.send_message(f"✅ **{player}** set to **{count}** anchors for Day {setting['day']}.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="day", description="ADMIN: Set the current Oil Clash event day, 1–7")
async def day(interaction: discord.Interaction, number: app_commands.Range[int, 1, 7]):
    ensure_admin(interaction)
    db.set_day(gid(interaction), number)
    await interaction.response.send_message(f"✅ Now tracking **Day {number}**. Earlier daily reports are saved and player roles stay the same.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="new_event", description="ADMIN: Begin a new 7-day Oil Clash, keeping members and roles")
async def new_event(interaction: discord.Interaction):
    ensure_admin(interaction)
    s = db.next_event(gid(interaction))
    await interaction.response.send_message(
        f"✅ New **Oil Clash event #{s['event_number']}**, Day 1 started. "
        "Roster and roles preserved. Anchors and reset checkmarks for this event begin fresh.", ephemeral=True
    )
    await update_saved_panel(gid(interaction))


@oil.command(name="remove", description="ADMIN: Permanently delete a player and their reports")
@app_commands.autocomplete(player=player_suggestions)
async def remove(interaction: discord.Interaction, player: str):
    ensure_admin(interaction)
    db.delete_player(gid(interaction), player)
    await interaction.response.send_message(f"✅ Deleted **{player}** and their saved reports.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="export", description="ADMIN: Download roster, roles and today's anchor report as CSV")
async def export(interaction: discord.Interaction):
    ensure_admin(interaction)
    settings = db.settings(gid(interaction))
    payload = db.export_csv(gid(interaction))
    await interaction.response.send_message(
        "CSV export ready. (To keep full history, also back up the SQLite database.)",
        file=discord.File(io.BytesIO(payload), filename=f"oil_event{settings['event_number']}_day{settings['day']}.csv"),
        ephemeral=True
    )


@bot.event
async def on_ready():
    log.info("Oil Clash online: %s (%s)", bot.user, bot.user.id if bot.user else "-")


@bot.event
async def setup_hook():
    bot.add_view(OilPanel())  # Stable custom IDs keep buttons working through bot restarts.
    bot.tree.add_command(oil)
    if TEST_GUILD_ID.isdigit():
        guild = discord.Object(id=int(TEST_GUILD_ID))
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        log.info("Synced %d slash-command groups to test guild %s", len(synced), TEST_GUILD_ID)
    else:
        synced = await bot.tree.sync()
        log.info("Synced %d global slash-command groups. Global propagation can take time.", len(synced))


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    root = getattr(error, "original", error)
    if isinstance(root, ValueError):
        await respond_error(interaction, str(root))
    else:
        log.exception("Oil Clash command failed: %s", error)
        await respond_error(interaction, "Something went wrong. Check bot logs or ask an admin.")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Create a .env file; see README.md.")
    bot.run(TOKEN, log_handler=None)
