"""Checks deployment-specific guardrails without connecting to Discord."""
import ast
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class LaunchPreflight(unittest.TestCase):
    def test_command_group_stays_below_discord_25_limit(self):
        module = ast.parse((ROOT / "bot.py").read_text(encoding="utf8"))
        names = []
        for item in module.body:
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for decorator in item.decorator_list:
                if (isinstance(decorator, ast.Call)
                        and isinstance(decorator.func, ast.Attribute)
                        and isinstance(decorator.func.value, ast.Name)
                        and decorator.func.value.id == "oil"
                        and decorator.func.attr == "command"):
                    names.append(next(kw.value.value for kw in decorator.keywords if kw.arg == "name"))
        self.assertEqual(len(names), len(set(names)))
        self.assertLessEqual(len(names), 25)
        self.assertIn("@oiltools.command(name=\"checkin\"", (ROOT / "bot.py").read_text())
        for needed in ("panel", "set_online", "batch", "day", "new_week", "clear_players", "full_reset", "roster"):
            self.assertIn(needed, names)

    def test_persistent_button_ids_unique(self):
        source = (ROOT / "bot.py").read_text(encoding="utf8")
        ids = re.findall(r'custom_id="(oil_clash:v2:[a-z_]+)"', source)
        self.assertEqual(4, len(ids))
        self.assertEqual(len(ids), len(set(ids)))
        self.assertIn("bot.add_view(OilPanel())", source)
        self.assertIn("timeout=None", source)

    def test_launch_files_no_secrets(self):
        for filename in ("Dockerfile", "compose.yaml", ".env.example", ".gitignore", "launch.sh", "README.md"):
            self.assertTrue((ROOT / filename).is_file(), filename)
        self.assertFalse((ROOT / ".env").exists())
        self.assertFalse((ROOT / "data/oil_clash.sqlite3").exists())
        self.assertIn(".env", (ROOT / ".gitignore").read_text())
        self.assertIn("./data:/app/data", (ROOT / "compose.yaml").read_text())


if __name__ == "__main__":
    unittest.main()
