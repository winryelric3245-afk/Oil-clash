"""SQLite persistence for Oil Clash. No Discord dependency: easy to test."""
from __future__ import annotations

import csv
import io
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

DEFAULT_ROLES = ("Lair Hitter", "Rig Holder")
MAX_NAME = 64
MAX_ROLE = 36


def normalize_name(name: str) -> str:
    name = " ".join(name.strip().split())
    if not name or len(name) > MAX_NAME or "\n" in name or "|" in name:
        raise ValueError(f"Player name must contain 1–{MAX_NAME} characters and no | separator.")
    return name


def normalize_role(role: str) -> str:
    role = " ".join(role.strip().split())
    if not role or len(role) > MAX_ROLE or "|" in role or "," in role:
        raise ValueError(f"Role must contain 1–{MAX_ROLE} characters and no | or comma.")
    return role


def parse_player_lines(text: str) -> tuple[list[dict], list[str]]:
    """Format: Name | Role A, Role B | Power in M | @mention or Discord ID.

    Missing columns allowed, including 'Name' alone.
    A Discord mention can be specified in ANY of the optional columns.
    """
    players: list[dict] = []
    errors: list[str] = []
    for line_number, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        fields = [x.strip() for x in line.split("|")]
        if len(fields) > 4:
            errors.append(f"Line {line_number}: too many | columns")
            continue
        try:
            name = normalize_name(fields[0])
            role_names: list[str] = []
            power = None
            discord_id = None
            for chunk in fields[1:]:
                if not chunk:
                    continue
                matched = re.fullmatch(r"<@!?(\d{15,22})>|(\d{15,22})", chunk)
                if matched:
                    discord_id = int(matched.group(1) or matched.group(2))
                    continue
                power_text = chunk.lower().replace(" ", "")
                matched_power = re.fullmatch(r"(\d+(?:\.\d+)?)m?", power_text)
                if matched_power and ("." in chunk or power_text.endswith("m") or len(fields) >= 3):
                    power = float(matched_power.group(1))
                    if not 0 <= power <= 9999:
                        raise ValueError("power must be 0–9999M")
                    continue
                role_names.extend(normalize_role(r) for r in chunk.split(",") if r.strip())
            players.append({"name": name, "roles": list(dict.fromkeys(role_names)), "power_m": power, "discord_id": discord_id})
        except ValueError as exc:
            errors.append(f"Line {line_number}: {exc}")
    return players, errors


class OilDB:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.setup()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path, timeout=15)
        try:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA foreign_keys=ON")
            db.execute("PRAGMA busy_timeout=15000")
            with db:
                yield db
        finally:
            db.close()

    def setup(self) -> None:
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS guilds (
                    guild_id INTEGER PRIMARY KEY,
                    event_number INTEGER NOT NULL DEFAULT 1 CHECK(event_number>=1),
                    day INTEGER NOT NULL DEFAULT 1 CHECK(day BETWEEN 1 AND 7),
                    panel_channel_id INTEGER,
                    panel_message_id INTEGER
                );
                CREATE TABLE IF NOT EXISTS players (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER NOT NULL,
                    name TEXT NOT NULL COLLATE NOCASE,
                    discord_id INTEGER,
                    power_m REAL,
                    march_b_m REAL,
                    march_c_m REAL,
                    UNIQUE(guild_id, name),
                    FOREIGN KEY(guild_id) REFERENCES guilds(guild_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS roles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER NOT NULL,
                    name TEXT NOT NULL COLLATE NOCASE,
                    UNIQUE(guild_id, name),
                    FOREIGN KEY(guild_id) REFERENCES guilds(guild_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS player_roles (
                    player_id INTEGER NOT NULL,
                    role_id INTEGER NOT NULL,
                    PRIMARY KEY(player_id, role_id),
                    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE,
                    FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS online_reports (
                    guild_id INTEGER NOT NULL,
                    event_number INTEGER NOT NULL,
                    day INTEGER NOT NULL,
                    player_id INTEGER NOT NULL,
                    online INTEGER NOT NULL CHECK(online IN (0,1)),
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(guild_id, event_number, day, player_id),
                    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS anchor_reports (
                    guild_id INTEGER NOT NULL,
                    event_number INTEGER NOT NULL,
                    day INTEGER NOT NULL,
                    player_id INTEGER NOT NULL,
                    anchors INTEGER NOT NULL CHECK(anchors BETWEEN 1 AND 25),
                    reported_at TEXT NOT NULL,
                    PRIMARY KEY(guild_id, event_number, day, player_id),
                    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
                );
            """)
            # Non-destructive upgrade of databases created with v1.
            existing = {row["name"] for row in db.execute("PRAGMA table_info(guilds)")}
            if "panel_channel_id" not in existing:
                db.execute("ALTER TABLE guilds ADD COLUMN panel_channel_id INTEGER")
            if "panel_message_id" not in existing:
                db.execute("ALTER TABLE guilds ADD COLUMN panel_message_id INTEGER")
        self.migrate_multi_accounts()
        with self.connect() as db:
            cols = {row["name"] for row in db.execute("PRAGMA table_info(players)")}
            for col in ("march_b_m", "march_c_m"):
                if col not in cols:
                    db.execute(f"ALTER TABLE players ADD COLUMN {col} REAL")
            db.execute("CREATE INDEX IF NOT EXISTS idx_players_owner ON players(guild_id,discord_id)")

    def migrate_multi_accounts(self) -> None:
        """Safely remove the old one-account-per-Discord UNIQUE constraint.

        Keep the *same* player IDs, preserving roles and historical anchor/online
        reports. Run transactionally with foreign keys disabled for table swap.
        """
        with sqlite3.connect(self.path, timeout=15, isolation_level=None) as con:
            con.row_factory = sqlite3.Row
            old = con.execute("SELECT sql FROM sqlite_master WHERE name='players' AND type='table'").fetchone()
            if not old or "UNIQUE(guild_id, discord_id)" not in old["sql"]:
                return
            con.execute("PRAGMA foreign_keys=OFF")
            try:
                con.execute("BEGIN IMMEDIATE")
                con.execute("""CREATE TABLE players_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER NOT NULL,
                    name TEXT NOT NULL COLLATE NOCASE,
                    discord_id INTEGER,
                    power_m REAL,
                    march_b_m REAL,
                    march_c_m REAL,
                    UNIQUE(guild_id, name),
                    FOREIGN KEY(guild_id) REFERENCES guilds(guild_id) ON DELETE CASCADE
                )""")
                cols = {row["name"] for row in con.execute("PRAGMA table_info(players)")}
                b = "march_b_m" if "march_b_m" in cols else "NULL"
                c = "march_c_m" if "march_c_m" in cols else "NULL"
                con.execute(f"""INSERT INTO players_new
                    (id,guild_id,name,discord_id,power_m,march_b_m,march_c_m)
                    SELECT id,guild_id,name,discord_id,power_m,{b},{c} FROM players""")
                con.execute("DROP TABLE players")
                con.execute("ALTER TABLE players_new RENAME TO players")
                if con.execute("PRAGMA foreign_key_check").fetchall():
                    raise RuntimeError("Database migration failed: foreign key violations")
                con.execute("COMMIT")
            except Exception:
                con.execute("ROLLBACK")
                raise
            finally:
                con.execute("PRAGMA foreign_keys=ON")

    def save_panel(self, guild_id: int, channel_id: int, message_id: int) -> None:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            db.execute("UPDATE guilds SET panel_channel_id=?,panel_message_id=? WHERE guild_id=?",
                       (channel_id, message_id, guild_id))

    def panel_location(self, guild_id: int) -> tuple[int, int] | None:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            row = db.execute("SELECT panel_channel_id,panel_message_id FROM guilds WHERE guild_id=?", (guild_id,)).fetchone()
            if row["panel_channel_id"] and row["panel_message_id"]:
                return row["panel_channel_id"], row["panel_message_id"]
            return None

    @staticmethod
    def _init_guild(db: sqlite3.Connection, guild_id: int) -> None:
        db.execute("INSERT OR IGNORE INTO guilds(guild_id) VALUES (?)", (guild_id,))
        db.executemany("INSERT OR IGNORE INTO roles(guild_id,name) VALUES (?,?)", [(guild_id, name) for name in DEFAULT_ROLES])

    def settings(self, guild_id: int) -> dict:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            return dict(db.execute("SELECT event_number,day FROM guilds WHERE guild_id=?", (guild_id,)).fetchone())

    def set_day(self, guild_id: int, day: int) -> None:
        if not 1 <= day <= 7:
            raise ValueError("Day must be 1–7.")
        with self.connect() as db:
            self._init_guild(db, guild_id)
            db.execute("UPDATE guilds SET day=? WHERE guild_id=?", (day, guild_id))

    def next_event(self, guild_id: int) -> dict:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            db.execute("UPDATE guilds SET day=1, event_number=event_number+1 WHERE guild_id=?", (guild_id,))
            return dict(db.execute("SELECT event_number,day FROM guilds WHERE guild_id=?", (guild_id,)).fetchone())

    @staticmethod
    def _player_by_name(db: sqlite3.Connection, guild_id: int, name: str):
        return db.execute("SELECT * FROM players WHERE guild_id=? AND name=? COLLATE NOCASE", (guild_id, name)).fetchone()

    @staticmethod
    def _player_by_discord(db: sqlite3.Connection, guild_id: int, discord_id: int):
        return db.execute("SELECT * FROM players WHERE guild_id=? AND discord_id=?", (guild_id, discord_id)).fetchone()

    @staticmethod
    def _power(value: float | None) -> float | None:
        if value is None:
            return None
        try:
            value = float(value)
        except (ValueError, TypeError):
            raise ValueError("March power must be a number of millions (e.g. 42.5).")
        if not 0 <= value <= 9999 or not __import__("math").isfinite(value):
            raise ValueError("March power must be between 0 and 9999M.")
        return round(value, 3)

    def upsert_player(self, guild_id: int, name: str, discord_id: int | None = None, power_m: float | None = None) -> int:
        name = normalize_name(name)
        power_m = self._power(power_m)
        with self.connect() as db:
            self._init_guild(db, guild_id)
            player = self._player_by_name(db, guild_id, name)
            if player:
                if discord_id is not None and player["discord_id"] not in (None, discord_id):
                    raise ValueError(f"{name} is linked to a different Discord account. Ask an admin to review it.")
                db.execute("UPDATE players SET discord_id=COALESCE(?,discord_id), power_m=COALESCE(?,power_m) WHERE id=?",
                           (discord_id, power_m, player["id"]))
                return int(player["id"])
            cur = db.execute("INSERT INTO players(guild_id,name,discord_id,power_m) VALUES (?,?,?,?)", (guild_id, name, discord_id, power_m))
            return int(cur.lastrowid)

    def member_id(self, guild_id: int, discord_id: int, display_name: str) -> int:
        """Legacy helper: return first account owned; create one for first check-in."""
        with self.connect() as db:
            self._init_guild(db, guild_id)
            player = self._player_by_discord(db, guild_id, discord_id)
            if player:
                return int(player["id"])
        name = normalize_name(display_name)
        try:
            return self.upsert_player(guild_id, name, discord_id=discord_id)
        except ValueError as exc:
            raise ValueError("Your game name is linked elsewhere. Ask an admin to use /oil link.") from exc

    def register(self, guild_id: int, discord_id: int, game_name: str, power_m: float | None = None) -> int:
        """Register an additional game account; never overwrite an existing owner."""
        return self.upsert_player(guild_id, game_name, discord_id, power_m)

    def admin_link(self, guild_id: int, name: str, discord_id: int) -> None:
        name = normalize_name(name)
        with self.connect() as db:
            player = self._player_by_name(db, guild_id, name)
            if not player:
                raise ValueError("Player not found in roster. Add them first.")
            if player["discord_id"] not in (None, discord_id):
                raise ValueError("This game name is linked to another Discord account. Use /oil unlink first.")
            db.execute("UPDATE players SET discord_id=? WHERE id=?", (discord_id, player["id"]))

    def member_accounts(self, guild_id: int, discord_id: int) -> list[dict]:
        return [p for p in self.roster(guild_id) if p["discord_id"] == discord_id]

    def owned_account(self, guild_id: int, discord_id: int, name: str | None = None) -> dict:
        owned = self.member_accounts(guild_id, discord_id)
        if not owned:
            raise ValueError("First tap 👤 Add Game Account to register your game name.")
        if name:
            p = next((p for p in owned if p["name"].casefold() == normalize_name(name).casefold()), None)
            if not p:
                raise ValueError("That game name is not linked to your Discord account.")
            return p
        if len(owned) > 1:
            raise ValueError("You have multiple game accounts. Choose a game account first.")
        return owned[0]

    def set_marches(self, guild_id: int, name: str, a: float | None = None,
                    b: float | None = None, c: float | None = None) -> dict:
        """None means keep the stored value; use 0 to enter a zero-strength march."""
        values = [self._power(value) for value in (a, b, c)]
        if all(v is None for v in values):
            raise ValueError("Provide at least one march power (A, B, or C).")
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Game account not found.")
            db.execute("""UPDATE players SET power_m=COALESCE(?,power_m),
                march_b_m=COALESCE(?,march_b_m), march_c_m=COALESCE(?,march_c_m)
                WHERE id=?""", (*values, p["id"]))
            return {"name":p["name"],"id":p["id"]}

    def set_owned_marches(self, guild_id: int, discord_id: int, name: str,
                          a: float | None = None, b: float | None = None,
                          c: float | None = None) -> dict:
        owned = self.owned_account(guild_id, discord_id, name)
        return self.set_marches(guild_id, owned["name"], a, b, c)

    def unlink(self, guild_id: int, name: str) -> None:
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Player not found.")
            db.execute("UPDATE players SET discord_id=NULL WHERE id=?", (p["id"],))

    def rename(self, guild_id: int, old: str, new: str) -> None:
        new = normalize_name(new)
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(old))
            if not p:
                raise ValueError("Player not found.")
            try:
                db.execute("UPDATE players SET name=? WHERE id=?", (new, p["id"]))
            except sqlite3.IntegrityError as exc:
                raise ValueError("That name is already in the roster.") from exc

    def delete_player(self, guild_id: int, name: str) -> None:
        with self.connect() as db:
            cur = db.execute("DELETE FROM players WHERE guild_id=? AND name=? COLLATE NOCASE", (guild_id, normalize_name(name)))
            if cur.rowcount == 0:
                raise ValueError("Player not found.")

    def add_role_type(self, guild_id: int, role: str) -> None:
        role = normalize_role(role)
        with self.connect() as db:
            self._init_guild(db, guild_id)
            db.execute("INSERT OR IGNORE INTO roles(guild_id,name) VALUES (?,?)", (guild_id, role))

    def role_types(self, guild_id: int) -> list[str]:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            return [r["name"] for r in db.execute("SELECT name FROM roles WHERE guild_id=? ORDER BY name COLLATE NOCASE", (guild_id,))]

    def add_player_role(self, guild_id: int, name: str, role: str, create: bool = False) -> None:
        role = normalize_role(role)
        with self.connect() as db:
            self._init_guild(db, guild_id)
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Player not found. Use /oil batch or /oil register first.")
            if create:
                db.execute("INSERT OR IGNORE INTO roles(guild_id,name) VALUES (?,?)", (guild_id, role))
            r = db.execute("SELECT id FROM roles WHERE guild_id=? AND name=? COLLATE NOCASE", (guild_id, role)).fetchone()
            if not r:
                raise ValueError("Role not found. Use /oil role_new first.")
            db.execute("INSERT OR IGNORE INTO player_roles(player_id,role_id) VALUES (?,?)", (p["id"], r["id"]))

    def remove_player_role(self, guild_id: int, name: str, role: str) -> None:
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Player not found.")
            db.execute("DELETE FROM player_roles WHERE player_id=? AND role_id IN (SELECT id FROM roles WHERE guild_id=? AND name=? COLLATE NOCASE)", (p["id"], guild_id, normalize_role(role)))

    def batch(self, guild_id: int, records: list[dict]) -> tuple[int, list[str]]:
        ok = 0
        errors = []
        for rec in records:
            try:
                self.upsert_player(guild_id, rec["name"], rec.get("discord_id"), rec.get("power_m"))
                for role in rec.get("roles", []):
                    self.add_player_role(guild_id, rec["name"], role, create=True)
                ok += 1
            except (ValueError, sqlite3.IntegrityError) as exc:
                errors.append(f"{rec['name']}: {exc}")
        return ok, errors

    def report_anchors(self, guild_id: int, player_id: int, anchors: int) -> dict:
        if not 1 <= anchors <= 25:
            raise ValueError("Anchors must be 1–25.")
        with self.connect() as db:
            self._init_guild(db, guild_id)
            s = db.execute("SELECT event_number, day FROM guilds WHERE guild_id=?", (guild_id,)).fetchone()
            if not db.execute("SELECT id FROM players WHERE id=? AND guild_id=?", (player_id, guild_id)).fetchone():
                raise ValueError("Player not found in this server.")
            db.execute("""INSERT INTO anchor_reports(guild_id,event_number,day,player_id,anchors,reported_at)
                          VALUES(?,?,?,?,?,?)
                          ON CONFLICT(guild_id,event_number,day,player_id)
                          DO UPDATE SET anchors=excluded.anchors,reported_at=excluded.reported_at""",
                       (guild_id, s["event_number"], s["day"], player_id, anchors, datetime.now(timezone.utc).isoformat()))
            return dict(s)

    def report_online(self, guild_id: int, player_id: int, online: bool) -> dict:
        """Day-scoped reset readiness. Only explicit True is green; default is red."""
        if type(online) is not bool:
            raise ValueError("Online status must be True or False.")
        with self.connect() as db:
            self._init_guild(db, guild_id)
            s = db.execute("SELECT event_number, day FROM guilds WHERE guild_id=?", (guild_id,)).fetchone()
            row = db.execute("SELECT id FROM players WHERE id=? AND guild_id=?", (player_id, guild_id)).fetchone()
            if row is None:
                raise ValueError("Player not found in this server.")
            db.execute("""INSERT INTO online_reports(guild_id,event_number,day,player_id,online,updated_at)
                          VALUES(?,?,?,?,?,?)
                          ON CONFLICT(guild_id,event_number,day,player_id)
                          DO UPDATE SET online=excluded.online,updated_at=excluded.updated_at""",
                       (guild_id, s["event_number"], s["day"], player_id, int(online), datetime.now(timezone.utc).isoformat()))
            return dict(s)

    def admin_online(self, guild_id: int, name: str, online: bool) -> dict:
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Player not found.")
            pid = p["id"]
        return self.report_online(guild_id, pid, online)

    def admin_report(self, guild_id: int, name: str, anchors: int) -> dict:
        with self.connect() as db:
            p = self._player_by_name(db, guild_id, normalize_name(name))
            if not p:
                raise ValueError("Player not found.")
            pid = p["id"]
        return self.report_anchors(guild_id, pid, anchors)

    def roster(self, guild_id: int) -> list[dict]:
        with self.connect() as db:
            self._init_guild(db, guild_id)
            rows = db.execute("""
                SELECT p.id, p.name, p.discord_id, p.power_m, p.power_m AS march_a_m,
                       p.march_b_m, p.march_c_m, a.anchors, a.reported_at,
                       COALESCE(o.online, 0) AS online_before_reset,
                       o.updated_at AS online_updated_at,
                COALESCE((SELECT GROUP_CONCAT(name, ', ') FROM (
                    SELECT r.name FROM roles r
                    JOIN player_roles pr ON pr.role_id=r.id
                    WHERE pr.player_id=p.id ORDER BY r.name COLLATE NOCASE)), '') AS roles
                FROM players p JOIN guilds g ON g.guild_id=p.guild_id
                LEFT JOIN anchor_reports a ON a.player_id=p.id AND a.guild_id=p.guild_id
                    AND a.day=g.day AND a.event_number=g.event_number
                LEFT JOIN online_reports o ON o.player_id=p.id AND o.guild_id=p.guild_id
                    AND o.day=g.day AND o.event_number=g.event_number
                WHERE p.guild_id=? ORDER BY p.name COLLATE NOCASE
            """, (guild_id,)).fetchall()
            return [dict(x) for x in rows]

    def report_for_member(self, guild_id: int, discord_id: int) -> dict | None:
        accounts = self.member_accounts(guild_id, discord_id)
        return accounts[0] if len(accounts) == 1 else None

    def export_csv(self, guild_id: int) -> bytes:
        settings = self.settings(guild_id)
        rows = self.roster(guild_id)
        f = io.StringIO()
        writer = csv.writer(f)
        writer.writerow(["Event", "Day", "Player", "Discord ID", "March A (M)", "March B (M)", "March C (M)", "Roles", "Reported Anchors", "Online Before Reset", "Anchors Updated UTC", "Online Updated UTC"])
        for p in rows:
            writer.writerow([settings["event_number"], settings["day"], p["name"], p["discord_id"] or "", p["march_a_m"] if p["march_a_m"] is not None else "", p["march_b_m"] if p["march_b_m"] is not None else "", p["march_c_m"] if p["march_c_m"] is not None else "", p["roles"], p["anchors"] if p["anchors"] is not None else "", "Yes" if p["online_before_reset"] else "No", p["reported_at"] or "", p["online_updated_at"] or ""])
        return ('\ufeff' + f.getvalue()).encode("utf-8")
