# OAO Oil Clash — Discord Bot

A simple, **standalone** Discord bot for Tiles Survive Oil Clash. No special Discord intents or access to your game account required. Players check in manually; the bot does not read the game or verify Discord presence at reset.

## v3 update: One Discord account, multiple game accounts, individual marches

**Member panel:** `/oil panel` now shows a name-by-name list with 🟢/🔴 reset availability, **each account's anchors**, **March A/B/C strength in millions**, and Oil Clash role(s). Discord embed limits mean the panel may display the first group of names; use `/oil roster` for the full roster. Each game account has **independent** anchor and reset reports.

Five simple buttons: **✅ Online**, **❌ Not online**, **⚓ Anchors**, **👤 Add Account**, and **⚔️ March A/B/C**. Tap 👤 again to add alt accounts on the same Discord login. When you have more than one game account, the bot asks you to select which one you're updating. Members may edit each march separately by entering power in millions (example `42.5`). Optional slash command: `/oil marches a:42.5 b:37 c:30 game_name:Winry`.

**Admins:** `/oil set_marches` can correct any account's A/B/C power; `/oil link` can associate multiple imported accounts to the same Discord person. The older `/oil power` and imported power value represent March A. Roles stay per game account, not per Discord member. Existing profiles, previously assigned roles and past reports are retained by the automated database migration.

**Upgrading the running DigitalOcean bot using an iPhone:**

1. Download `OAO_Oil_Clash_Bot_v3.zip` and upload **the ZIP** to your GitHub `Oil-clash` repository (main branch); commit changes.
2. On your DigitalOcean `oao-oil-clash` Console, paste this block. It updates only bot code; it **keeps the current `.env` token and `data/` database**.

```bash
cd /opt/oil-clash && git pull --ff-only && \
unzip -o OAO_Oil_Clash_Bot_v3.zip -d bot-files && \
cd bot-files/oil-clash-bot && \
docker compose up -d --build && \
docker compose logs --tail=25
```

3. In Discord use `/oil panel` to post the refreshed dashboard. Existing v2 buttons keep working, and the new ⚔️ button appears when the bot edits the saved panel or a new panel is posted.

**Important:** Never delete `/opt/oil-clash/bot-files/oil-clash-bot/data`, upload `.env` or share your token. Do not unzip into a new working directory; that would create a new empty database.

## 1. Members: tap buttons (no typing commands)

An admin posts a **single check-in panel** using `/oil panel` in an Oil Clash channel. The updated panel has five buttons:

| Button | Action |
|---|---|
| 👤 **Add Account** | Add another account at any time. If you are in the batch-imported roster, enter **the exact same** game name to preserve the admin-assigned roles. |
| ✅ **Online before reset** (green) | Save a **green** checkmark for the current day. This is **your own confirmation** you plan to be online, not automated game presence. |
| ❌ **Not online** (red) | Save a **red** cross for the current day. |
| ⚓ **Anchors** | Pop-up asks for **1–25** for the selected game account. |
| ⚔️ **March A/B/C** | Edit three per-account march strengths in millions, e.g. `45.2`. |

Members appear 🔴 **red / not confirmed** each new event day until they choose green. The roster shows their status, number of anchors, and admin-assigned role(s). **Each day's status and anchor count are separate.** Older reports are kept when switching days; alliance names, roles, and optional march power carry forward.

The panel's counts refresh after button taps, slash check-ins, batch imports and admin day changes. If a check-in is saved but a panel refresh fails (e.g. missing message permissions), the member's data is still stored.

Alternative one-step slash command: `/oil checkin anchors:23 online_before_reset:true`. Personal reports: `/oil me`. List: `/oil roster`. Totals: `/oil summary`. Slash command `/oil anchors count:23` remains supported.

**Important:** register or tap 👤 *before* submitting anchors/availability. This stops accidental duplicates between imported game names and Discord display names. Members whose game names were linked to Discord IDs during import do not need to register again.

## 2. Admin: simple controls

- `/oil panel` — post the check-in panel. Post it **once per channel**; the bot remembers the most recent panel it posted and refreshes it automatically.
- `/oil batch` — paste many players into the `players` field, **or** upload a plain UTF-8 `.txt` roster in `file`. Batch imports add/update entries without deleting older players or resetting check-ins. Limit: **500 per batch**.
- `/oil role_add player:Winry role:Rig Holder` — assign a role. `/oil role_remove` removes one. Players can hold multiple roles. Built-in roles: **Lair Hitter** and **Rig Holder**. Create more with `/oil role_new`.
- `/oil set_online player:Winry online:true` — manually fix reset availability; use `false` to mark red.
- `/oil set_anchors player:Winry count:23` — correct someone's anchor number.
- `/oil day number:2` — switch to another day **1–7**; today's report/checkmarks reset to that day's records, the pinned panel is updated. Changing back to an earlier day restores its reports.
- `/oil new_event` — start the next Oil Clash round at Day 1. Keeps all player profiles, power and roles, but resets the day's anchors and green checkmarks.
- `/oil roster not_online_only:true` — who has **red** status. `/oil roster missing_only:true` — who hasn't entered anchors. Add `public:true` to post in channel instead of privately.
- `/oil summary` — green/red totals, team anchors and role totals.
- `/oil export` — download the current day's CSV (including online availability); back up the SQLite database for **full multi-day history**.

Other admin tools: `/oil link`, `/oil unlink`, `/oil rename`, `/oil remove`, `/oil role_list`. Use `/oil help` in Discord for a short list. Admin privileges: server **Manage Server** permission or a role specified in `OIL_ADMIN_ROLE_IDS`.

### Batch import format

Use **one player per line**, with `|` separators:

```text
Ashley | Lair Hitter | 47M
Winry | Rig Holder | 43.5M
Wahid | Lair Hitter, Rig Holder | 28M
Spotato | Rig Holder
Quicksilver
```

Optional last field: actual Discord mention or numeric Discord user ID (e.g., `<@123456789012345678>`); linking prevents duplicate profiles. Game name alone is also valid. *Typing an @name as plain text is not the same as an actual Discord mention.* Existing profiles and roles survive subsequent imports.

## 3. Discord setup (new bot; doesn't touch existing bots)

1. Visit **https://discord.com/developers/applications**, select **New Application**, name it **Oil Clash**.
2. Open **Bot**, create/copy the bot token. **Never put this token in chat, a screenshot, your GitHub repository, or the public ZIP.** If a token is exposed, reset it in the Portal.
3. In **Installation**, enable the **Guild Install** link and select `bot` + `applications.commands` scopes. Grant bot `Send Messages`, `Embed Links`, `Read Message History`, `View Channel`, and `Attach Files` permissions. No privileged Message Content or Server Members intent is needed.
4. Invite the bot to your alliance's Discord server.
5. For fast slash-command sync, copy your server ID (Discord Settings → Advanced → Developer Mode; right-click server → Copy Server ID). Add it as `TEST_GUILD_ID` below. Without it, global commands can take time to appear.

## 4. DigitalOcean / Docker Compose launch

Run this on your **own DigitalOcean Droplet** with Docker Engine and Docker Compose installed. Put this folder in its own location (e.g. `/opt/oil-clash-bot`) separate from other bots.

```bash
cd /opt/oil-clash-bot
cp .env.example .env
nano .env   # paste your NEW Oil Clash bot token into DISCORD_TOKEN
./launch.sh
```

In `.env`, set:

```dotenv
DISCORD_TOKEN=your_secret_bot_token
TEST_GUILD_ID=your_discord_server_id
# optional comma-separated IDs of the Discord leadership roles:
OIL_ADMIN_ROLE_IDS=
OIL_DB_PATH=data/oil_clash.sqlite3
```

**Do not add `.env` to GitHub.** The `.gitignore` included in this package excludes `.env` and the database.

Useful commands:

```bash
# Build or update bot (also applies .env changes):
docker compose up -d --build --force-recreate
# View health and logs:
docker compose ps
docker compose logs --tail=100 oil-clash
# Stop without erasing database:
docker compose down
# Check bot database tests (requires local Python, no Discord install):
python3 -m unittest discover -s tests -v
```

The data volume is `./data:/app/data`, so reports and roles persist through restarts and image rebuilds. **Do not run `docker compose down -v` or delete `data/`.** For a database-safe live backup:

```bash
python3 -c 'import sqlite3; a=sqlite3.connect("data/oil_clash.sqlite3"); b=sqlite3.connect("oil_clash_backup.sqlite3"); a.backup(b); b.close(); a.close()'
```

## 5. First-use checklist

1. Bot must show **online in Discord**; check `docker compose logs` for a synced `/oil` command group.
2. Admin runs `/oil batch` with player list (no need for power or roles if unknown).
3. Admin runs `/oil panel` in the Oil Clash channel and pins that Discord message.
4. Members tap 👤 to link their imported game name; then submit green/red reset availability and anchors.
5. Admin runs `/oil roster`, `/oil summary`, and checks `not_online_only:true` to see red players.
6. At the next Oil Clash day, admin runs `/oil day number:2`; the panel updates and defaults to red until confirmation.
7. At the next Oil Clash round, admin runs `/oil new_event`.

## 6. Event mechanics and limitations

- Oil Clash runs in staged days with building unlocks. Adjacent, controlled territory is required for captures in the user's live version; **this bot does not plot paths or auto-assign building targets**.
- The bot accepts **1–25** as requested, so members can report claimed and saved attempts when applicable. It does not assume that 25 is a guaranteed in-game active inventory cap.
- Roles are labels for planning, not automated combat orders: **Lair Hitter** and **Rig Holder**; the game and battle plan determine what to do.
- In-game release changes can affect Oil Clash. For example, official notes changed alliance-leaving eligibility and occupied-building resource payouts (https://tilessurvive.com/en/blog/968 and https://tilessurvive.com/en/blog/975).
- Discord Presence is **not** used to decide the green/red status: the member/admin marks it manually as their **planned before-reset availability**.

## 7. Testing and deployment limits

`python3 -m unittest discover -s tests -v` covers batch import, 40-player deduplication, database persistence, default-red status, green/red toggles, admin corrections, day/round changes, CSV export, old-database upgrade and panel-location storage. `python3 -m compileall -q bot.py storage.py` validates Python syntax. A **live Discord/Docker test** still requires a new bot token, server invite and an available Docker machine; source-code tests do **not** prove Discord network delivery.
