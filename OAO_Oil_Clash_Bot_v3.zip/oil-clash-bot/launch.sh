#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo 'Docker Engine + docker compose are required. See README.md.' >&2
  exit 1
fi
if [[ ! -f .env ]]; then
  cp .env.example .env
  echo 'Created .env — open it and set the NEW Discord token, then run ./launch.sh again.' >&2
  exit 1
fi
if ! grep -Eq '^DISCORD_TOKEN=[^[:space:]]+' .env || grep -Eq '^DISCORD_TOKEN=(PASTE_|your_secret_bot_token)' .env; then
  echo 'Add a valid DISCORD_TOKEN to .env before launching.' >&2
  exit 1
fi
echo 'Building and launching separate Oil Clash container...'
docker compose up -d --build --force-recreate
docker compose ps
printf '\nUse: docker compose logs --tail=100 oil-clash\n'
