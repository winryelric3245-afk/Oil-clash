"""Oil Clash: standalone Discord slash-command bot for Tiles Survive."""
from __future__ import annotations

import io
import logging
import os

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from storage import OilDB, parse_player_lines

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
TEST_GUILD_ID = os.getenv("TEST_GUILD_ID", "").strip()
DB_PATH = os.getenv("OIL_DB_PATH", "data/oil_clash.sqlite3")
ADMIN_ROLE_IDS = {
    int(s.strip()) for s in os.getenv("OIL_ADMIN_ROLE_IDS", "").split(",")
    if s.strip().isdigit()
}
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("oilclash")
db = OilDB(DB_PATH)

intents = discord.Intents.default()
intents.message_content = False
intents.members = False
bot = commands.Bot(command_prefix="!unused-", intents=intents)
oil = app_commands.Group(name="oil", description="Oil Clash anchors and alliance roles")


def gid(interaction: discord.Interaction) -> int:
    if interaction.guild_id is None:
        raise ValueError("Use Oil Clash commands inside your alliance Discord server.")
    return interaction.guild_id


def ensure_admin(interaction: discord.Interaction) -> None:
    if not isinstance(interaction.user, discord.Member):
        raise ValueError("Admin commands must be used in a server.")
    if interaction.user.guild_permissions.manage_guild:
        return
    if any(r.id in ADMIN_ROLE_IDS for r in interaction.user.roles):
        return
    raise ValueError("Admin only. Requires Manage Server or a configured Oil Clash admin role.")


async def respond_error(interaction: discord.Interaction, message: str) -> None:
    message = "❌ " + message[:1700]
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


async def player_suggestions(interaction: discord.Interaction, current: str):
    try:
        matches = [p["name"] for p in db.roster(gid(interaction)) if current.casefold() in p["name"].casefold()]
        return [app_commands.Choice(name=n[:100], value=n[:100]) for n in matches[:25]]
    except ValueError:
        return []


async def role_suggestions(interaction: discord.Interaction, current: str):
    try:
        matches = [r for r in db.role_types(gid(interaction)) if current.casefold() in r.casefold()]
        return [app_commands.Choice(name=r, value=r) for r in matches[:25]]
    except ValueError:
        return []


# Persistent, mobile-friendly dashboard. Keep v2 button IDs for existing posts.
def march_text(p: dict) -> str:
    def show(x):
        return f"{x:g}" if x is not None else "—"
    return f"A:{show(p['march_a_m'])} B:{show(p['march_b_m'])} C:{show(p['march_c_m'])}M"


def panel_embed(server_id: int) -> discord.Embed:
    setting = db.settings(server_id)
    accounts = db.roster(server_id)
    ready = sum(bool(p["online_before_reset"]) for p in accounts)
    reported = [p for p in accounts if p["anchors"] is not None]
    total = sum(p["anchors"] for p in reported)
    description = (
        "**Add game accounts, then check in each account daily.**\n"
        "🟢 = confirmed before reset  |  🔴 = not confirmed\n"
        "⚓ = anchors today  |  A/B/C = march power in millions\n"
        "*Red is the default each new day; this is player-reported, not live presence.*"
    )
    card = discord.Embed(
        title=f"🛢️ OIL CLASH | Event {setting['event_number']} • Day {setting['day']}/7",
        description=description,
        color=discord.Color.green() if accounts and ready == len(accounts) else discord.Color.orange(),
    )
    card.add_field(name="🟢 Confirmed", value=f"**{ready}/{len(accounts)}**", inline=True)
    card.add_field(name="🔴 Not confirmed", value=f"**{len(accounts)-ready}**", inline=True)
    card.add_field(name="⚓ Anchors", value=f"**{total}** · {len(reported)}/{len(accounts)} accounts", inline=False)
    # Discord embeds limit *each field* to 1024 characters and the whole
    # embed to 6000. Split player lines into safe chunks without clipping names.
    chunks: list[str] = []
    chunk = ""
    displayed = 0
    for p in accounts:
        name = discord.utils.escape_markdown(p['name'])[:65]
        status = "🟢" if p["online_before_reset"] else "🔴"
        count = str(p["anchors"]) if p["anchors"] is not None else "—"
        roles = discord.utils.escape_markdown(p['roles'] or 'Unassigned')[:32]
        line = f"{status} **{name}** · ⚓{count} · {march_text(p)} · {roles}"
        if sum(len(c) for c in chunks) + len(chunk) + len(line) + 2 > 5000:
            break
        if len(chunk) + len(line) + 1 > 950:
            chunks.append(chunk.rstrip())
            chunk = ""
        chunk += line + "\n"
        displayed += 1
    if chunk:
        chunks.append(chunk.rstrip())
    remaining = len(accounts) - displayed
    if accounts:
        for idx, chunk in enumerate(chunks):
            card.add_field(name="Player accounts · anchors · marches · roles" if idx == 0 else f"Accounts (cont. {idx+1})",
                           value=chunk, inline=False)
        if remaining:
            card.add_field(name="Full roster", value=f"**+{remaining} more accounts.** Use `/oil roster` to see all.", inline=False)
    else:
        card.add_field(name="Player accounts", value="Nobody registered yet. Tap 👤 Add Account to start.", inline=False)
    card.set_footer(text="Each game account has independent anchors & reset status • /oil roster shows full list")
    return card


async def refresh_panel(interaction: discord.Interaction, source: discord.Message | None = None) -> None:
    message = source or interaction.message
    if message is None or interaction.guild_id is None:
        return
    try:
        await message.edit(embed=panel_embed(interaction.guild_id), view=OilPanel())
    except (discord.HTTPException, discord.Forbidden) as exc:
        log.warning("Could not refresh Oil Clash panel: %s", exc)


async def update_saved_panel(server_id: int) -> None:
    location = db.panel_location(server_id)
    if not location:
        return
    channel_id, message_id = location
    try:
        channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
        message = await channel.fetch_message(message_id)
        await message.edit(embed=panel_embed(server_id), view=OilPanel())
    except (discord.HTTPException, discord.Forbidden, AttributeError) as exc:
        log.warning("Could not update saved Oil Clash panel %s/%s: %s", channel_id, message_id, exc)


def linked_player(interaction: discord.Interaction, name: str | None = None) -> dict:
    return db.owned_account(gid(interaction), interaction.user.id, name)


async def own_account_suggestions(interaction: discord.Interaction, current: str):
    try:
        return [app_commands.Choice(name=p['name'][:100], value=p['name'][:100])
                for p in db.member_accounts(gid(interaction), interaction.user.id)
                if current.casefold() in p['name'].casefold()][:25]
    except ValueError:
        return []


class AnchorModal(discord.ui.Modal, title="Oil Clash • Anchors"):
    amount = discord.ui.TextInput(label="Anchors today (1–25)", placeholder="Example: 23", min_length=1, max_length=2)

    def __init__(self, source: discord.Message | None, account: dict):
        super().__init__(timeout=300)
        self.source = source
        self.account = account

    async def on_submit(self, interaction: discord.Interaction):
        try:
            p = linked_player(interaction, self.account["name"])
            raw = str(self.amount.value).strip()
            if not raw.isdecimal():
                raise ValueError("Enter a whole number from 1 to 25.")
            value = int(raw)
            setting = db.report_anchors(gid(interaction), p["id"], value)
            await interaction.response.send_message(
                f"✅ **{p['name']}**: {value} anchors saved for Day {setting['day']}.", ephemeral=True)
            await refresh_panel(interaction, self.source)
        except (ValueError, TypeError) as exc:
            await respond_error(interaction, str(exc))


class MarchModal(discord.ui.Modal, title="Oil Clash • March Power (Millions)"):
    a = discord.ui.TextInput(label="A march (M)", placeholder="42.5 or leave empty to keep", required=False, max_length=10)
    b = discord.ui.TextInput(label="B march (M)", placeholder="37 or leave empty to keep", required=False, max_length=10)
    c = discord.ui.TextInput(label="C march (M)", placeholder="28.3 or leave empty to keep", required=False, max_length=10)

    def __init__(self, source: discord.Message | None, account: dict):
        super().__init__(timeout=300)
        self.source = source
        self.account = account
        self.a.default = str(account['march_a_m']) if account['march_a_m'] is not None else ""
        self.b.default = str(account['march_b_m']) if account['march_b_m'] is not None else ""
        self.c.default = str(account['march_c_m']) if account['march_c_m'] is not None else ""

    async def on_submit(self, interaction: discord.Interaction):
        try:
            p = linked_player(interaction, self.account["name"])
            def parse(field):
                value = str(field.value).strip().removesuffix('M').removesuffix('m').strip()
                return float(value) if value else None
            db.set_owned_marches(gid(interaction), interaction.user.id, p["name"],
                                 parse(self.a), parse(self.b), parse(self.c))
            new = db.owned_account(gid(interaction), interaction.user.id, p["name"])
            await interaction.response.send_message(
                f"✅ **{p['name']}** marches updated: {march_text(new)}", ephemeral=True)
            await refresh_panel(interaction, self.source)
        except (ValueError, TypeError) as exc:
            await respond_error(interaction, f"Enter march power in millions (e.g. 42.5). {exc}")


class NameModal(discord.ui.Modal, title="Oil Clash • Add Game Account"):
    game_name = discord.ui.TextInput(label="In-game account name", placeholder="Use exact roster name if already imported", max_length=64)

    def __init__(self, source: discord.Message | None):
        super().__init__(timeout=300)
        self.source = source

    async def on_submit(self, interaction: discord.Interaction):
        try:
            if len(db.member_accounts(gid(interaction), interaction.user.id)) >= 25:
                raise ValueError("Maximum 25 accounts per Discord member; ask an admin for help.")
            account = str(self.game_name.value).strip()
            db.register(gid(interaction), interaction.user.id, account)
            await interaction.response.send_message(
                f"✅ Game account **{discord.utils.escape_markdown(account)}** linked. You can add more accounts with the same button.", ephemeral=True)
            await refresh_panel(interaction, self.source)
        except ValueError as exc:
            await respond_error(interaction, str(exc))


class AccountSelect(discord.ui.Select):
    def __init__(self, accounts: list[dict], action: str):
        self.action = action
        options = [discord.SelectOption(label=p['name'][:100], value=str(p['id']),
                                        description=f"{p['anchors'] if p['anchors'] is not None else '—'} anchors • {march_text(p)}"[:100])
                   for p in accounts[:25]]
        super().__init__(placeholder="Select the game account to update", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        view: AccountPicker = self.view
        if interaction.user.id != view.owner_id:
            await respond_error(interaction, "This account picker belongs to someone else.")
            return
        try:
            p = next((p for p in db.member_accounts(gid(interaction), interaction.user.id)
                      if p['id'] == int(self.values[0])), None)
            if p is None:
                raise ValueError("That account is no longer linked to you.")
            if self.action == "anchors":
                await interaction.response.send_modal(AnchorModal(view.source, p))
            elif self.action == "marches":
                await interaction.response.send_modal(MarchModal(view.source, p))
            else:
                online = self.action == "ready"
                setting = db.report_online(gid(interaction), p['id'], online)
                await interaction.response.send_message(
                    f"{'🟢 ✅' if online else '🔴 ❌'} **{p['name']}**: "
                    f"{'online' if online else 'not online'} before reset for Day {setting['day']}.",
                    ephemeral=True)
                await refresh_panel(interaction, view.source)
        except ValueError as exc:
            await respond_error(interaction, str(exc))


class AccountPicker(discord.ui.View):
    def __init__(self, owner_id: int, accounts: list[dict], action: str, source: discord.Message | None):
        super().__init__(timeout=150)
        self.owner_id = owner_id
        self.source = source
        self.add_item(AccountSelect(accounts, action))


class OilPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def choose(self, interaction: discord.Interaction, action: str) -> None:
        accounts = db.member_accounts(gid(interaction), interaction.user.id)
        if not accounts:
            await respond_error(interaction, "Tap 👤 Add Account first, then check in.")
            return
        if len(accounts) > 1:
            await interaction.response.send_message("Which game account?", ephemeral=True,
                view=AccountPicker(interaction.user.id, accounts, action, interaction.message))
            return
        p = accounts[0]
        if action == "anchors":
            await interaction.response.send_modal(AnchorModal(interaction.message, p))
        elif action == "marches":
            await interaction.response.send_modal(MarchModal(interaction.message, p))
        else:
            online = action == "ready"
            setting = db.report_online(gid(interaction), p['id'], online)
            await interaction.response.send_message(
                f"{'🟢 ✅' if online else '🔴 ❌'} **{p['name']}** "
                f"{'online' if online else 'not online'} before reset for Day {setting['day']}.", ephemeral=True)
            await refresh_panel(interaction)

    @discord.ui.button(label="Online before reset", emoji="✅", style=discord.ButtonStyle.success, custom_id="oil_clash:v2:ready")
    async def ready(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "ready")

    @discord.ui.button(label="Not online", emoji="❌", style=discord.ButtonStyle.danger, custom_id="oil_clash:v2:not_ready")
    async def not_ready(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "not_ready")

    @discord.ui.button(label="Anchors", emoji="⚓", style=discord.ButtonStyle.primary, custom_id="oil_clash:v2:anchors")
    async def anchors_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "anchors")

    @discord.ui.button(label="Add Account", emoji="👤", style=discord.ButtonStyle.secondary, custom_id="oil_clash:v2:name")
    async def name_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(NameModal(interaction.message))

    @discord.ui.button(label="March A/B/C", emoji="⚔️", style=discord.ButtonStyle.secondary, custom_id="oil_clash:v3:marches")
    async def marches_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "marches")


@oil.command(name="panel", description="ADMIN: Post the simple Oil Clash check-in buttons")
async def panel(interaction: discord.Interaction):
    ensure_admin(interaction)
    await interaction.response.send_message(embed=panel_embed(gid(interaction)), view=OilPanel(), allowed_mentions=discord.AllowedMentions.none())
    message = await interaction.original_response()
    db.save_panel(gid(interaction), interaction.channel_id, message.id)


@oil.command(name="checkin", description="Save one game account's anchors and reset status")
@app_commands.describe(anchors="Anchors (1–25)", online_before_reset="Will this account be online before reset?", game_name="Required if you have multiple game accounts")
@app_commands.autocomplete(game_name=own_account_suggestions)
async def checkin(interaction: discord.Interaction, anchors: app_commands.Range[int, 1, 25], online_before_reset: bool, game_name: str | None = None):
    p = linked_player(interaction, game_name)
    setting = db.report_anchors(gid(interaction), p["id"], anchors)
    db.report_online(gid(interaction), p["id"], online_before_reset)
    status = "🟢 ✅ online" if online_before_reset else "🔴 ❌ not online"
    await interaction.response.send_message(f"✅ **{p['name']}** Day {setting['day']}: **{anchors}** anchors · {status} before reset.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="set_online", description="ADMIN: Set a player's before-reset availability")
@app_commands.autocomplete(player=player_suggestions)
async def set_online(interaction: discord.Interaction, player: str, online: bool):
    ensure_admin(interaction)
    setting = db.admin_online(gid(interaction), player, online)
    status = "🟢 ✅ online" if online else "🔴 ❌ not online"
    await interaction.response.send_message(f"**{discord.utils.escape_markdown(player)}**: {status} before reset (Day {setting['day']}).", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="help", description="Player and admin commands")
async def oil_help(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**OIL CLASH v3**\n"
        "Panel: 👤 Add Account (repeat for alts) · ⚓ Anchors · 🟢/🔴 reset status · ⚔️ March A/B/C. "
        "With multiple game accounts, choose the account from the private picker first.\n"
        "`/oil register` adds another account; `/oil me` lists all of yours.\n"
        "`/oil roster` shows names, roles, anchors, reset status and A/B/C march power.\n"
        "Admins: `/oil batch`, `/oil link`, `/oil role_add`, `/oil set_marches`, "
        "`/oil set_anchors`, `/oil day`, `/oil summary`, `/oil export`.\n"
        "Statuses and anchors change per day; roles and march power persist.", ephemeral=True)


@oil.command(name="register", description="Add another in-game account to your Discord login")
@app_commands.describe(game_name="Exact in-game name", march_power_m="Optional March A power in millions")
async def register(interaction: discord.Interaction, game_name: str, march_power_m: float | None = None):
    if len(db.member_accounts(gid(interaction), interaction.user.id)) >= 25:
        raise ValueError("Maximum 25 accounts per Discord member.")
    player_id = db.register(gid(interaction), interaction.user.id, game_name, march_power_m)
    await interaction.response.send_message(f"✅ Linked **{discord.utils.escape_markdown(game_name)}** as a game account (#{player_id}). Add more with `/oil register` or 👤.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="power", description="Update March A power for one of your game accounts")
@app_commands.describe(march_power_m="March A power in millions, e.g. 45.2", game_name="Required if you have multiple game accounts")
@app_commands.autocomplete(game_name=own_account_suggestions)
async def power(interaction: discord.Interaction, march_power_m: float, game_name: str | None = None):
    p = linked_player(interaction, game_name)
    db.set_owned_marches(gid(interaction), interaction.user.id, p['name'], a=march_power_m)
    await interaction.response.send_message(f"✅ **{p['name']}** March A updated to **{march_power_m:g}M**.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="marches", description="Edit your game account's A, B or C march power (millions)")
@app_commands.describe(a="March A power in M", b="March B power in M", c="March C power in M", game_name="Required for multiple game accounts")
@app_commands.autocomplete(game_name=own_account_suggestions)
async def marches(interaction: discord.Interaction, a: float | None = None, b: float | None = None,
                  c: float | None = None, game_name: str | None = None):
    p = linked_player(interaction, game_name)
    db.set_owned_marches(gid(interaction), interaction.user.id, p['name'], a, b, c)
    updated = linked_player(interaction, p['name'])
    await interaction.response.send_message(f"✅ **{p['name']}**: {march_text(updated)}", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="anchors", description="Save anchors for one of your game accounts (1–25)")
@app_commands.describe(count="Your current anchors, 1–25", game_name="Required if you have multiple game accounts")
@app_commands.autocomplete(game_name=own_account_suggestions)
async def anchors(interaction: discord.Interaction, count: app_commands.Range[int, 1, 25], game_name: str | None = None):
    p = linked_player(interaction, game_name)
    setting = db.report_anchors(gid(interaction), p['id'], count)
    await interaction.response.send_message(f"✅ **{p['name']}**: {count} anchors saved for Day {setting['day']}.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="me", description="See all game accounts linked to your Discord login")
async def me(interaction: discord.Interaction):
    accounts = db.member_accounts(gid(interaction), interaction.user.id)
    if not accounts:
        await interaction.response.send_message("No game accounts yet. Tap 👤 Add Account or `/oil register`.", ephemeral=True)
        return
    s = db.settings(gid(interaction))
    lines = [f"**{discord.utils.escape_markdown(p['name'])}** · {'🟢' if p['online_before_reset'] else '🔴'} · "
             f"⚓{p['anchors'] if p['anchors'] is not None else '—'} · {march_text(p)} · {p['roles'] or 'Unassigned'}"
             for p in accounts]
    await interaction.response.send_message(
        f"**Your Oil Clash accounts · Event {s['event_number']} Day {s['day']}**\n" + "\n".join(lines)[:1750],
        ephemeral=True, allowed_mentions=discord.AllowedMentions.none())


@oil.command(name="roster", description="Show roster, daily anchors, roles, and missing check-ins")
@app_commands.describe(role="Optional role filter", missing_only="Only missing anchor reports", not_online_only="Only red (not confirmed)", public="Post in channel instead of privately")
@app_commands.autocomplete(role=role_suggestions)
async def roster(interaction: discord.Interaction, role: str | None = None, missing_only: bool = False, not_online_only: bool = False, public: bool = False):
    s = db.settings(gid(interaction))
    people = db.roster(gid(interaction))
    if role:
        people = [p for p in people if role.casefold() in [x.casefold() for x in p["roles"].split(", ")]]
    if missing_only:
        people = [p for p in people if p["anchors"] is None]
    if not_online_only:
        people = [p for p in people if not p["online_before_reset"]]
    title = f"OIL CLASH | Event {s['event_number']} · Day {s['day']}"
    if not people:
        await interaction.response.send_message(f"**{title}**\nNo players match the current filters.", ephemeral=not public)
        return
    lines = []
    for p in people:
        number = str(p["anchors"]) if p["anchors"] is not None else "—"
        pw = f" · {march_text(p)}"
        status = "🟢 ✅" if p["online_before_reset"] else "🔴 ❌"
        line = f"{status} **{discord.utils.escape_markdown(p['name'])}** · ⚓{number} · {discord.utils.escape_markdown(p['roles'] or 'Unassigned')}{pw}"
        lines.append(line)
    reported = sum(p["anchors"] is not None for p in people)
    online = sum(p["online_before_reset"] for p in people)
    heading = f"**{title}**\n🟢 {online} online · 🔴 {len(people)-online} not confirmed · ⚓ {reported}/{len(people)} reported\n\n"
    body = "\n".join(lines)
    if len(heading + body) <= 1900:
        await interaction.response.send_message(heading + body, ephemeral=not public, allowed_mentions=discord.AllowedMentions.none())
    else:
        safe_lines = [f"{'GREEN online' if p['online_before_reset'] else 'RED not confirmed'} | {p['name']} | {p['anchors'] if p['anchors'] is not None else '-'} anchors | {p['roles'] or 'Unassigned'} | {march_text(p)}" for p in people]
        out = (title + "\nReset | Player | Anchors | Roles | March A/B/C (M)\n\n" + "\n".join(safe_lines)).encode("utf-8")
        preview_lines = []
        current_length = len(heading) + 45
        for line in lines:
            if current_length + len(line) > 1750 or len(preview_lines) == 15:
                break
            preview_lines.append(line)
            current_length += len(line) + 1
        preview = "\n".join(preview_lines)
        await interaction.response.send_message(
            heading + preview + "\n…Full list attached.",
            file=discord.File(io.BytesIO(out), filename="oil_clash_roster.txt"),
            ephemeral=not public, allowed_mentions=discord.AllowedMentions.none()
        )


@oil.command(name="summary", description="Team anchor totals and missing check-ins")
@app_commands.describe(public="Post in channel instead of privately")
async def summary(interaction: discord.Interaction, public: bool = False):
    s = db.settings(gid(interaction))
    people = db.roster(gid(interaction))
    completed = [p for p in people if p["anchors"] is not None]
    not_ready = [p["name"] for p in people if not p["online_before_reset"]]
    missing = [p["name"] for p in people if p["anchors"] is None]
    total = sum(p["anchors"] for p in completed)
    ready = sum(bool(p["online_before_reset"]) for p in people)
    roles = db.role_types(gid(interaction))
    details = []
    for role in roles:
        assigned = [p for p in people if role.casefold() in [x.casefold() for x in p["roles"].split(", ")]]
        if assigned:
            reported = sum(p["anchors"] is not None for p in assigned)
            count = sum(p["anchors"] or 0 for p in assigned)
            online = sum(bool(p["online_before_reset"]) for p in assigned)
            details.append(f"{role}: **{count}** anchors · 🟢 {online}/{len(assigned)} online · ⚓ {reported}/{len(assigned)} reported")
    msg = (
        f"**OIL CLASH SUMMARY — Event {s['event_number']}, Day {s['day']}**\n"
        f"Members: **{len(people)}** · Reported: **{len(completed)}** · Missing: **{len(missing)}**\n"
        f"🟢 Online before reset: **{ready}** · 🔴 Not confirmed: **{len(people)-ready}**\n"
        f"Total reported anchors: **{total}**\n\n"
        + ("\n".join(details) if details else "No assigned roles yet.")
        + "\n\n*Role totals may overlap for members with multiple roles.*"
        + ("\n🔴 Not confirmed: " + ", ".join(discord.utils.escape_markdown(n) for n in not_ready[:15]) + (f" (+{len(not_ready)-15} more)" if len(not_ready) > 15 else "") if not_ready else "")
        + ("\n⚓ Missing anchors: " + ", ".join(discord.utils.escape_markdown(n) for n in missing[:15]) + (f" (+{len(missing)-15} more)" if len(missing) > 15 else "") if missing else "")
    )
    await interaction.response.send_message(msg[:1900], ephemeral=not public, allowed_mentions=discord.AllowedMentions.none())


@oil.command(name="batch", description="ADMIN: Add/update many game names, roles, power and optional Discord IDs")
@app_commands.describe(players="Paste one player per line (or attach a .txt file)", file="Optional UTF-8 .txt roster for large imports")
async def batch(interaction: discord.Interaction, players: str | None = None, file: discord.Attachment | None = None):
    ensure_admin(interaction)
    if not players and not file:
        raise ValueError("Paste players or attach a .txt file. Format: Name | Lair Hitter | 35.5M | @DiscordUser")
    await interaction.response.defer(ephemeral=True)
    payload = players or ""
    if file:
        if file.size > 80_000:
            raise ValueError("Import file must be under 80 KB.")
        try:
            payload += "\n" + (await file.read()).decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("Roster file must be UTF-8 text.") from exc
    records, parse_errors = parse_player_lines(payload)
    if len(records) > 500:
        raise ValueError("Maximum 500 players per batch.")
    ok, import_errors = db.batch(gid(interaction), records)
    errors = parse_errors + import_errors
    result = f"✅ **{ok} players added/updated**. Names, roles, and Discord links are saved."
    if errors:
        result += f"\n⚠️ {len(errors)} skipped/errors:\n" + "\n".join(errors[:12])
        if len(errors) > 12:
            result += f"\n...and {len(errors) - 12} more."
    await interaction.followup.send(result[:1900], ephemeral=True)
    if ok:
        await update_saved_panel(gid(interaction))


@oil.command(name="role_new", description="ADMIN: Create a role (e.g., Flex or Rig Backup)")
async def role_new(interaction: discord.Interaction, name: str):
    ensure_admin(interaction)
    db.add_role_type(gid(interaction), name)
    await interaction.response.send_message(f"✅ Role **{name}** is available for assignment.", ephemeral=True)


@oil.command(name="role_list", description="Show Oil Clash role labels")
async def role_list(interaction: discord.Interaction):
    roles = db.role_types(gid(interaction))
    await interaction.response.send_message("**Oil Clash roles:** " + (", ".join(roles) or "none"), ephemeral=True)


@oil.command(name="role_add", description="ADMIN: Assign another role to a player")
@app_commands.autocomplete(player=player_suggestions, role=role_suggestions)
async def role_add(interaction: discord.Interaction, player: str, role: str):
    ensure_admin(interaction)
    db.add_player_role(gid(interaction), player, role)
    await interaction.response.send_message(f"✅ **{player}** now has **{role}**.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="role_remove", description="ADMIN: Remove a role from a player")
@app_commands.autocomplete(player=player_suggestions, role=role_suggestions)
async def role_remove(interaction: discord.Interaction, player: str, role: str):
    ensure_admin(interaction)
    db.remove_player_role(gid(interaction), player, role)
    await interaction.response.send_message(f"✅ Removed **{role}** from **{player}**.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="link", description="ADMIN: Connect imported game name to a Discord member")
@app_commands.autocomplete(player=player_suggestions)
async def link(interaction: discord.Interaction, player: str, member: discord.Member):
    ensure_admin(interaction)
    db.admin_link(gid(interaction), player, member.id)
    await interaction.response.send_message(f"✅ Linked **{player}** to **{member.display_name}**.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="unlink", description="ADMIN: Disconnect a game name from its Discord member")
@app_commands.autocomplete(player=player_suggestions)
async def unlink(interaction: discord.Interaction, player: str):
    ensure_admin(interaction)
    db.unlink(gid(interaction), player)
    await interaction.response.send_message(f"✅ Unlinked **{player}**. Roles and reports remain.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="rename", description="ADMIN: Change a saved in-game name without losing reports")
@app_commands.autocomplete(player=player_suggestions)
async def rename(interaction: discord.Interaction, player: str, new_name: str):
    ensure_admin(interaction)
    db.rename(gid(interaction), player, new_name)
    await interaction.response.send_message(f"✅ Renamed **{player}** → **{new_name}**.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="set_marches", description="ADMIN: Enter or edit any player's A/B/C march power in M")
@app_commands.describe(player="Game account", a="March A in M", b="March B in M", c="March C in M")
@app_commands.autocomplete(player=player_suggestions)
async def set_marches(interaction: discord.Interaction, player: str, a: float | None = None,
                      b: float | None = None, c: float | None = None):
    ensure_admin(interaction)
    db.set_marches(gid(interaction), player, a, b, c)
    p = next(p for p in db.roster(gid(interaction)) if p['name'].casefold() == player.casefold())
    await interaction.response.send_message(f"✅ **{p['name']}**: {march_text(p)}", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="set_anchors", description="ADMIN: Correct a player's anchors for the active day")
@app_commands.autocomplete(player=player_suggestions)
async def set_anchors(interaction: discord.Interaction, player: str, count: app_commands.Range[int, 1, 25]):
    ensure_admin(interaction)
    setting = db.admin_report(gid(interaction), player, count)
    await interaction.response.send_message(f"✅ **{player}** set to **{count}** anchors for Day {setting['day']}.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="day", description="ADMIN: Set the current Oil Clash event day, 1–7")
async def day(interaction: discord.Interaction, number: app_commands.Range[int, 1, 7]):
    ensure_admin(interaction)
    db.set_day(gid(interaction), number)
    await interaction.response.send_message(f"✅ Now tracking **Day {number}**. Earlier daily reports are saved and player roles stay the same.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="new_event", description="ADMIN: Begin a new 7-day Oil Clash, keeping members and roles")
async def new_event(interaction: discord.Interaction):
    ensure_admin(interaction)
    s = db.next_event(gid(interaction))
    await interaction.response.send_message(
        f"✅ New **Oil Clash event #{s['event_number']}**, Day 1 started. "
        "Roster and roles preserved. Anchors and reset checkmarks for this event begin fresh.", ephemeral=True
    )
    await update_saved_panel(gid(interaction))


@oil.command(name="remove", description="ADMIN: Permanently delete a player and their reports")
@app_commands.autocomplete(player=player_suggestions)
async def remove(interaction: discord.Interaction, player: str):
    ensure_admin(interaction)
    db.delete_player(gid(interaction), player)
    await interaction.response.send_message(f"✅ Deleted **{player}** and their saved reports.", ephemeral=True)
    await update_saved_panel(gid(interaction))


@oil.command(name="export", description="ADMIN: Download roster, roles and today's anchor report as CSV")
async def export(interaction: discord.Interaction):
    ensure_admin(interaction)
    settings = db.settings(gid(interaction))
    payload = db.export_csv(gid(interaction))
    await interaction.response.send_message(
        "CSV export ready. (To keep full history, also back up the SQLite database.)",
        file=discord.File(io.BytesIO(payload), filename=f"oil_event{settings['event_number']}_day{settings['day']}.csv"),
        ephemeral=True
    )


@bot.event
async def on_ready():
    log.info("Oil Clash online: %s (%s)", bot.user, bot.user.id if bot.user else "-")


@bot.event
async def setup_hook():
    bot.add_view(OilPanel())  # Stable custom IDs keep buttons working through bot restarts.
    bot.tree.add_command(oil)
    if TEST_GUILD_ID.isdigit():
        guild = discord.Object(id=int(TEST_GUILD_ID))
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        log.info("Synced %d slash-command groups to test guild %s", len(synced), TEST_GUILD_ID)
    else:
        synced = await bot.tree.sync()
        log.info("Synced %d global slash-command groups. Global propagation can take time.", len(synced))


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    root = getattr(error, "original", error)
    if isinstance(root, ValueError):
        await respond_error(interaction, str(root))
    else:
        log.exception("Oil Clash command failed: %s", error)
        await respond_error(interaction, "Something went wrong. Check bot logs or ask an admin.")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Create a .env file; see README.md.")
    bot.run(TOKEN, log_handler=None)
