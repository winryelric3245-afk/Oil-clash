import csv
import importlib.util
import io
import sqlite3
import tempfile
import unittest
import zipfile
from pathlib import Path

from storage import OilDB, parse_player_lines

OLD_ZIP = Path('/mnt/data/OAO_Oil_Clash_Bot_Launch_Ready_v2.zip')


class MultipleAccountTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = OilDB(Path(self.tmp.name) / 'db.sqlite3')
        self.guild = 200
        self.owner = 123456789012345678
        self.other = 987654321098765432

    def tearDown(self):
        self.tmp.cleanup()

    def test_multiple_game_accounts_one_discord_identity(self):
        alice = self.db.register(self.guild, self.owner, 'Alice')
        bob = self.db.register(self.guild, self.owner, 'Bob')
        self.assertNotEqual(alice, bob)
        self.assertEqual(['Alice', 'Bob'], [p['name'] for p in self.db.member_accounts(self.guild, self.owner)])
        self.db.report_anchors(self.guild, alice, 25)
        self.db.report_anchors(self.guild, bob, 8)
        self.db.report_online(self.guild, alice, True)
        self.assertEqual([25, 8], [p['anchors'] for p in self.db.member_accounts(self.guild, self.owner)])
        self.assertEqual([1, 0], [p['online_before_reset'] for p in self.db.member_accounts(self.guild, self.owner)])
        with self.assertRaises(ValueError):
            self.db.owned_account(self.guild, self.owner)
        self.assertEqual('Bob', self.db.owned_account(self.guild, self.owner, 'Bob')['name'])
        with self.assertRaises(ValueError):
            self.db.owned_account(self.guild, self.other, 'Alice')
        with self.assertRaises(ValueError):
            self.db.register(self.guild, self.other, 'Alice')

    def test_march_powers_distinct_editable_and_persist(self):
        self.db.register(self.guild, self.owner, 'Main', power_m=40.5)
        self.db.register(self.guild, self.owner, 'Alt')
        self.db.set_owned_marches(self.guild, self.owner, 'Main', b=32.25, c=17.6)
        self.db.set_owned_marches(self.guild, self.owner, 'Alt', a=14, b=12, c=10)
        self.db.set_owned_marches(self.guild, self.owner, 'Main', b=35)
        a = self.db.owned_account(self.guild, self.owner, 'Main')
        b = self.db.owned_account(self.guild, self.owner, 'Alt')
        self.assertEqual([40.5,35,17.6], [a['march_a_m'],a['march_b_m'],a['march_c_m']])
        self.assertEqual([14,12,10], [b['march_a_m'],b['march_b_m'],b['march_c_m']])
        self.assertEqual(17.6, OilDB(self.db.path).owned_account(self.guild, self.owner, 'Main')['march_c_m'])
        for invalid in (-1,10000,float('nan'),float('inf')):
            with self.assertRaises(ValueError):
                self.db.set_marches(self.guild,'Main',a=invalid)
        with self.assertRaises(ValueError):
            self.db.set_marches(self.guild, 'Main')
        with self.assertRaises(ValueError):
            self.db.set_owned_marches(self.guild, self.other, 'Main', a=9)

    def test_existing_batch_and_admin_link_can_have_same_owner(self):
        self.db.batch(self.guild, [{'name':'First','roles':['Lair Hitter']}, {'name':'Second','roles':['Rig Holder']}])
        self.db.admin_link(self.guild,'First',self.owner)
        self.db.admin_link(self.guild,'Second',self.owner)
        self.assertEqual(2,len(self.db.member_accounts(self.guild,self.owner)))
        self.db.unlink(self.guild,'First')
        self.assertEqual(1,len(self.db.member_accounts(self.guild,self.owner)))
        self.assertEqual('Lair Hitter',next(x for x in self.db.roster(self.guild) if x['name']=='First')['roles'])
        self.db.admin_link(self.guild,'First',self.other)
        with self.assertRaises(ValueError):
            self.db.admin_link(self.guild,'First',self.owner)

    def test_day_reset_preserves_accounts_marches_roles(self):
        first = self.db.register(self.guild,self.owner,'First')
        second = self.db.register(self.guild,self.owner,'Second')
        self.db.add_player_role(self.guild,'Second','Rig Holder')
        self.db.set_marches(self.guild,'Second',a=47.5,b=30,c=25)
        self.db.report_anchors(self.guild,first,23)
        self.db.report_anchors(self.guild,second,11)
        self.db.report_online(self.guild,second,True)
        self.db.set_day(self.guild,2)
        accounts=self.db.member_accounts(self.guild,self.owner)
        self.assertTrue(all(p['anchors'] is None and p['online_before_reset']==0 for p in accounts))
        self.assertEqual((47.5,30,25),(accounts[1]['march_a_m'],accounts[1]['march_b_m'],accounts[1]['march_c_m']))
        self.assertEqual('Rig Holder',accounts[1]['roles'])
        self.db.next_event(self.guild)
        self.assertEqual(2,len(self.db.member_accounts(self.guild,self.owner)))

    def test_csv_has_individual_values(self):
        self.db.register(self.guild,self.owner,'A')
        self.db.register(self.guild,self.owner,'B')
        self.db.set_marches(self.guild,'B',a=50,b=42,c=35)
        rows=list(csv.DictReader(io.StringIO(self.db.export_csv(self.guild).decode('utf-8-sig'))))
        self.assertEqual('50.0',rows[1]['March A (M)'])
        self.assertEqual('42.0',rows[1]['March B (M)'])
        self.assertEqual('35.0',rows[1]['March C (M)'])
        self.assertEqual(str(self.owner),rows[0]['Discord ID'])
        self.assertEqual(str(self.owner),rows[1]['Discord ID'])

    def test_v2_to_v3_migration_preserves_data_and_ids(self):
        if not OLD_ZIP.exists():
            self.skipTest('No original v2 ZIP available')
        with tempfile.TemporaryDirectory() as root:
            with zipfile.ZipFile(OLD_ZIP) as z:
                names=[n for n in z.namelist() if n.endswith('/storage.py')]
                if not names:
                    self.skipTest('No original v2 storage in ZIP')
                old_path=Path(root)/'old_storage.py'
                old_path.write_bytes(z.read(names[0]))
                spec=importlib.util.spec_from_file_location('old_oil_storage',old_path)
                mod=importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
            path=Path(root)/'v2.sqlite3'
            old=mod.OilDB(path)
            old.register(self.guild,self.owner,'Main',33)
            old.add_player_role(self.guild,'Main','Rig Holder')
            old.report_anchors(self.guild,1,25)
            old.report_online(self.guild,1,True)
            old.save_panel(self.guild,123,456)
            upgraded=OilDB(path)
            self.assertEqual('Rig Holder',upgraded.roster(self.guild)[0]['roles'])
            self.assertEqual(25,upgraded.roster(self.guild)[0]['anchors'])
            self.assertEqual(1,upgraded.roster(self.guild)[0]['online_before_reset'])
            self.assertEqual(33,upgraded.roster(self.guild)[0]['march_a_m'])
            self.assertEqual((123,456),upgraded.panel_location(self.guild))
            pid=upgraded.register(self.guild,self.owner,'Alt')
            self.assertEqual(2,pid)
            self.assertEqual(2,len(OilDB(path).member_accounts(self.guild,self.owner)))
            with upgraded.connect() as con:
                self.assertEqual([],con.execute('PRAGMA foreign_key_check').fetchall())

    def test_all_40_roster_accounts_report_separately(self):
        records, errors=parse_player_lines('\n'.join(f'Account{x:02d} | Rig Holder' for x in range(40)))
        self.assertFalse(errors)
        self.assertEqual((40,[]),self.db.batch(self.guild,records))
        for idx,p in enumerate(self.db.roster(self.guild)):
            self.db.admin_link(self.guild,p['name'],self.owner if idx<8 else self.other)
            self.db.set_marches(self.guild,p['name'],a=idx+20,b=idx+18,c=idx+15)
            self.db.report_anchors(self.guild,p['id'],1+idx%25)
        self.assertEqual(40,len(self.db.roster(self.guild)))
        self.assertEqual(8,len(self.db.member_accounts(self.guild,self.owner)))
        self.assertEqual(32,len(self.db.member_accounts(self.guild,self.other)))


if __name__=='__main__':unittest.main()
