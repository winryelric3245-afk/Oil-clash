import csv
import io
import sqlite3
import tempfile
import unittest
from pathlib import Path

from storage import OilDB, parse_player_lines


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = OilDB(Path(self.tmp.name) / "oil.sqlite3")
        self.guild = 999

    def tearDown(self):
        self.tmp.cleanup()

    def test_batch_roles_and_persistence(self):
        text = "Ashley | Lair Hitter | 45.5M | <@123456789012345678>\nWinry | Rig Holder\nWahid | Lair Hitter, Rig Holder | 22M"
        people, errors = parse_player_lines(text)
        self.assertEqual([], errors)
        self.assertEqual(3, len(people))
        self.assertEqual((3, []), self.db.batch(self.guild, people))
        self.assertEqual((3, []), self.db.batch(self.guild, people))
        roster = self.db.roster(self.guild)
        self.assertEqual(3, len(roster))
        self.assertEqual(2, len([x for x in roster if "Rig Holder" in x["roles"]]))
        self.assertEqual(45.5, roster[0]["power_m"])
        new_db = OilDB(self.db.path)
        self.assertEqual(3, len(new_db.roster(self.guild)))

    def test_anchors_days_and_events(self):
        pid = self.db.member_id(self.guild, 123456789012345678, "Winry")
        self.db.add_player_role(self.guild, "Winry", "Rig Holder")
        self.db.report_anchors(self.guild, pid, 25)
        self.assertEqual(25, self.db.roster(self.guild)[0]["anchors"])
        self.db.set_day(self.guild, 2)
        self.assertIsNone(self.db.roster(self.guild)[0]["anchors"])
        self.db.report_anchors(self.guild, pid, 9)
        self.db.set_day(self.guild, 1)
        self.assertEqual(25, self.db.roster(self.guild)[0]["anchors"])
        self.db.next_event(self.guild)
        self.assertIsNone(self.db.roster(self.guild)[0]["anchors"])
        self.assertEqual("Rig Holder", self.db.roster(self.guild)[0]["roles"])

    def test_register_link_and_dedup(self):
        self.db.batch(self.guild, [{"name": "GameName", "roles": ["Lair Hitter"]}])
        self.db.register(self.guild, 123456789012345678, "GameName")
        self.db.report_anchors(self.guild, self.db.member_id(self.guild, 123456789012345678, "discordname"), 4)
        self.assertEqual(1, len(self.db.roster(self.guild)))
        with self.assertRaises(ValueError):
            self.db.register(self.guild, 999999999999999999, "GameName")

    def test_validation_and_export(self):
        pid = self.db.member_id(self.guild, 123456789012345678, "Chief")
        for val in (0, 26, 100):
            with self.assertRaises(ValueError):
                self.db.report_anchors(self.guild, pid, val)
        self.db.report_anchors(self.guild, pid, 1)
        self.assertIn(b"Chief", self.db.export_csv(self.guild))
        _, errors = parse_player_lines("A | Lair Hitter\nB | bad | 33M | abc | extra")
        self.assertEqual(1, len(errors))

    def test_role_changes_and_rename(self):
        self.db.upsert_player(self.guild, "Alice")
        self.db.add_player_role(self.guild, "Alice", "Lair Hitter")
        self.db.rename(self.guild, "Alice", "Ali")
        self.db.remove_player_role(self.guild, "Ali", "Lair Hitter")
        self.assertEqual("", self.db.roster(self.guild)[0]["roles"])

    def test_online_checkmarks_and_daily_reset(self):
        """New days default RED; green is strictly confirmed for that day."""
        pid = self.db.member_id(self.guild, 123456789012345678, "Winry")
        self.assertEqual(0, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.report_online(self.guild, pid, True)
        self.assertEqual(1, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.report_online(self.guild, pid, False)
        self.assertEqual(0, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.report_online(self.guild, pid, True)
        self.db.set_day(self.guild, 2)
        self.assertEqual(0, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.set_day(self.guild, 1)
        self.assertEqual(1, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.next_event(self.guild)
        self.assertEqual(0, self.db.roster(self.guild)[0]["online_before_reset"])

    def test_online_admin_override(self):
        self.db.upsert_player(self.guild, "Ashley")
        self.db.admin_online(self.guild, "Ashley", True)
        self.assertEqual(1, self.db.roster(self.guild)[0]["online_before_reset"])
        self.db.admin_online(self.guild, "Ashley", False)
        self.assertEqual(0, self.db.roster(self.guild)[0]["online_before_reset"])
        with self.assertRaises(ValueError):
            self.db.admin_online(self.guild, "Missing", True)
        with self.assertRaises(ValueError):
            self.db.report_online(self.guild, 99999, True)
        with self.assertRaises(ValueError):
            self.db.report_online(self.guild, 1, "yes")

    def test_batch_40_players_default_red_keep_roles(self):
        source = "\n".join(f"Player{i:02d} | {'Rig Holder' if i % 2 else 'Lair Hitter'} | {i + 20}M" for i in range(1, 41))
        records, err = parse_player_lines(source)
        self.assertEqual([], err)
        self.assertEqual((40, []), self.db.batch(self.guild, records))
        self.assertEqual((40, []), self.db.batch(self.guild, records))
        rows = self.db.roster(self.guild)
        self.assertEqual(40, len(rows))
        self.assertEqual(40, sum(p["online_before_reset"] == 0 for p in rows))
        self.assertEqual(40, sum(bool(p["roles"]) for p in rows))
        self.db.admin_online(self.guild, "Player01", True)
        self.db.report_anchors(self.guild, rows[0]["id"], 23)
        self.db.batch(self.guild, records)
        self.assertEqual(1, sum(p["online_before_reset"] for p in self.db.roster(self.guild)))
        self.assertEqual(23, self.db.roster(self.guild)[0]["anchors"])

    def test_online_export(self):
        self.db.upsert_player(self.guild, "Ashley")
        self.db.admin_online(self.guild, "Ashley", True)
        rows = list(csv.DictReader(io.StringIO(self.db.export_csv(self.guild).decode("utf-8-sig"))))
        self.assertEqual("Yes", rows[0]["Online Before Reset"])
        self.db.set_day(self.guild, 2)
        rows = list(csv.DictReader(io.StringIO(self.db.export_csv(self.guild).decode("utf-8-sig"))))
        self.assertEqual("No", rows[0]["Online Before Reset"])

    def test_panel_location_persists_and_independent_guilds(self):
        self.assertIsNone(self.db.panel_location(self.guild))
        self.db.save_panel(self.guild, 456, 789)
        self.assertEqual((456, 789), self.db.panel_location(self.guild))
        self.assertIsNone(self.db.panel_location(self.guild + 1))
        reopened = OilDB(self.db.path)
        self.assertEqual((456, 789), reopened.panel_location(self.guild))
        reopened.next_event(self.guild)
        self.assertEqual((456, 789), reopened.panel_location(self.guild))

    def test_v1_database_migration_without_data_loss(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "previous.sqlite3"
            with sqlite3.connect(path) as old:
                old.execute("CREATE TABLE guilds (guild_id INTEGER PRIMARY KEY, event_number INTEGER NOT NULL DEFAULT 1, day INTEGER NOT NULL DEFAULT 1)")
                old.execute("INSERT INTO guilds VALUES (999, 2, 3)")
            upgraded = OilDB(path)
            self.assertEqual({"event_number": 2, "day": 3}, upgraded.settings(999))
            self.assertIsNone(upgraded.panel_location(999))
            upgraded.save_panel(999, 123, 456)
            self.assertEqual((123,456), upgraded.panel_location(999))

    def test_delete_player_cascades_daily_reports(self):
        self.db.upsert_player(self.guild, "Alice")
        self.db.admin_online(self.guild, "Alice", True)
        self.db.admin_report(self.guild, "Alice", 17)
        self.db.delete_player(self.guild, "Alice")
        self.assertEqual([], self.db.roster(self.guild))
        with self.db.connect() as con:
            self.assertEqual(0, con.execute("SELECT COUNT(*) FROM online_reports").fetchone()[0])
            self.assertEqual(0, con.execute("SELECT COUNT(*) FROM anchor_reports").fetchone()[0])



if __name__ == "__main__":
    unittest.main()
